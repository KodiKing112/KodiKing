# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[55]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    global links_reqzone
    progress='Start'
    start_time=time.time()
    all_links=[]

    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Alt-Used': 'reqfilm.com:443',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('searchtype',tv_movie),
        ('post_type',tv_movie),
        ('s', clean_name(original_title,1).replace(' ','+')),
    )
    progress='requests'
    html = requests.get('http://reqzone.com/?searchtype=movie&post_type=%s&s=%s'%(tv_movie,clean_name(original_title,1).replace(' ','+')), headers=headers).content
  
    
    regex='<h1 class="entry-title">(.+?)</footer>'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
   
    count=0
    for lk_data in match:
        progress='Links-'+str(count)
        count+=1
        regex='rel="bookmark">(.+?)<'
        progress='Regex-'+str(count)
        name=re.compile(regex).findall(lk_data)[0]
       
        if stop_all==1:
                    break
       
        x=lk_data
       
        if clean_name(original_title,1).lower() == name.lower():
             
             regex='<a href="(.+?)"'
             progress='Regex2-'+str(count)
             m=re.compile(regex).findall(lk_data)[0]
             progress='requests-'+str(count)
             html=requests.get(m, headers=headers).content
            
            
             
             if tv_movie=='tv':
               regex_pre='<span class="vc_tta-title-text">Season %s (.+?)<.+?<div class="wpb_text_column wpb_content_element ">(.+?)</div'%season
               progress='Regex3-'+str(count)
               match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
        
               for quality,items in match_pre:
                   regex='<h3 style="text-align: center;">Episode %s<.+?href="(.+?)"'%(episode)
                   progress='Regex4-'+str(count)
                   match2=re.compile(regex,re.DOTALL).findall(items)
                   
                   for link in match2:
                      if "1080" in quality:
                        res="1080"
                      elif "720" in quality:
                        res="720"
                      elif "480" in quality:
                        res="480"
                      elif "hd" in quality.lower():
                        res="HD"
                      else:
                       res=' '
                      all_links.append((original_title,link,'Direct',res))
                      global_var=all_links
             else:
               if '<h1 style="text-align: center;">'+clean_name(original_title,1) in html:
                 regex='<div class="wpb_wrapper">.+?<h1 style="text-align: center;">%s \(.+?<div class="wpb_wrapper">(.+?)</div>'%clean_name(original_title,1)
               else:
                 regex='<div class="wpb_wrapper">(.+?)</div>'
               progress='Regex5-'+str(count)
               match=re.compile(regex,re.DOTALL).findall(html)
               quality_save=''

               for links in match:
                 if stop_all==1:
                    break
                 regex_in='<h3 style="text-align: center;"><span style="color: .+?;">(.+?)<|Server (.+?)</h3>.+?<h3 style=.+?href="(.+?)"'
                 progress='Regex6-'+str(count)
                 match_in=re.compile(regex_in,re.DOTALL).findall(links)
                 for quality,server,link in match_in:
                  
                     if stop_all==1:
                        break
                     if len(link)>0:
             
                      if "1080" in quality_save:
                        res="1080"
                      elif "720" in quality_save:
                        res="720"
                      elif "480" in quality_save:
                        res="480"
                      elif "hd" in quality_save.lower():
                        res="HD"
                      else:
                       res=' '
                      all_links.append((original_title,link,'Direct',res))
                      global_var=all_links
                     else:
                       quality_save=quality
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
	