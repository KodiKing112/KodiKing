# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[96]
def resolve_movie(url):
    ids=url.split('/')
    id=ids[len(ids)-1]
    headers = {
        'pragma': 'no-cache',
        
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'accept': 'application/json, text/plain, */*',
        'cache-control': 'no-cache',
        'authority': 'load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com',
        'referer': 'https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com/',
    }

    params = (
        ('1', ''),
    )

    res = requests.get('https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com/api/app/getToken', headers=headers, params=params)
    headers = {
    'pragma': 'no-cache',
    
    'accept-encoding': 'utf-8',
    'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    'accept': 'application/json, text/plain, */*',
    'cache-control': 'no-cache',
    'authority': 'another.load.embed.is.vidnode.net.vidcloud.icu.openloadmovies.net.movienightplayer.com',
    'referer': 'https://another.load.embed.is.vidnode.net.vidcloud.icu.openloadmovies.net.movienightplayer.com/',
    }

    params = (
        ('1', ''),
    )

    res = requests.get('https://another.load.embed.is.vidnode.net.vidcloud.icu.openloadmovies.net.movienightplayer.com/api/app/getToken', headers=headers, params=params)



    
    

    response = requests.post('https://source.movienightplayer.com/api/getSource/%s/'%id+res.json()['data'],cookies=res.cookies, headers=headers,timeout=10).json()
  
    try:
        response2 = requests.get('https://source.movienightplayer.com/api/getEmbed/'+id+'/'+res.json()['data'],cookies=res.cookies, headers=headers,timeout=10).json()
    except:
        response2={}
    
   
    return response,(response2)
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
   
       
        all_links=[]
        url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
        
        imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
        url='https://movienightplayer.com/'+imdb_id
        
        all_links_in,all2=resolve_movie(url)
       
        for li in all_links_in['data']['sources']:
            
            if stop_all==1:
                    break
            if 'res' in li:
                res=str(li['res'])
            else:
                res='720'
                
                    
            all_links.append((original_title.replace("%20"," "),li['src'],'Direct',res))
            global_var=all_links
       
      
            
        
        
        if 'data' in all2:
            host=re.compile('//(.+?)/').findall(all2['data'])[0]
            all_links.append((original_title.replace("%20"," "),all2['data'],host,'720'))
            global_var=all_links
        return global_var