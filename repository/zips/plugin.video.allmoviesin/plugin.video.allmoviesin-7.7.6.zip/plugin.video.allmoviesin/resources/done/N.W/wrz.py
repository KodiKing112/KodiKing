# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains
type=['movie','tv','rd']

import urllib2,urllib,logging,base64,json

color=all_colors[89]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    import cfscrape
    print '1'
    base_link = 'http://wrzcraft.life/'
    search_id = clean_name(original_title.lower(),1)  
                        
    start_url = "%s/?s=%s+%s" % (base_link, search_id.replace(' ','+'),show_original_year)
    print start_url
    if tv_movie=='tv':
        season_url = "0%s"%season if len(season)<2 else season
        episode_url = "0%s"%episode if len(episode)<2 else episode
        sea_epi ='s%se%s'%(season_url,episode_url)
        
        search_id = clean_name(original_title.lower(),1)  
        start_url = "%s/?s=%s+%s" % (base_link, search_id.replace(' ','+'),sea_epi)

    print start_url
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'search.rlsbb.ru:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
    
    print start_url
    tk=cfscrape.get_tokens(start_url,headers=headers)
    print tk
    OPEN = requests.get(start_url,headers=tk[1],cookies=tk[0]).content
    all_links=[]
    content = re.compile('<h2><a href="(.+?)"',re.DOTALL).findall(OPEN)
    print content
    for url in content:
        if tv_movie=='movie':
            if 'truehd' in url:
                continue
        
     
        if not search_id.replace(' ','-') in clean_name(url,1).lower():
            continue
      
       
        links = requests.get(url,headers=tk[1],cookies=tk[0]).content
        Regex = re.compile('<singlelink>(.+?)</a><br />',re.DOTALL).findall(links)           
        LINK = re.compile('href="(.+?)"').findall(str(Regex))
        count = 0            
      
        
        for url in LINK:
            print url
            if '.rar' not in url:
                if '.srt' not in url:
                    if '1080' in url:
                        res = '1080p'
                    elif '720' in url:
                        res = '720p'
                    elif 'HDTV' in url:
                        res = 'DVD'
                    else:
                        pass

                    host = url.split('//')[1].replace('www.','')
                    host = host.split('/')[0].lower()
                    
                    # if not filter_host(host):
                        # continue
                            # if debrid == "true":
                    
                    if host in rd_domains:
                        name1,match_s,res,check=server_data(url,original_title)
                        
                        print url
                        if check :
                            if '.rar' not in name1:
                                all_links.append((name1,url,match_s,res))
                                global_var=all_links
    return global_var