# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    import universalscrapers

    if tv_movie=='movie':
      imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
      x=requests.get(imdbid_data).json()
      imdbid=x['imdb_id']
    else:
     imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
     x=requests.get(imdbid_data).json()

     imdbid=x['external_ids']['imdb_id']
    all_links=[]
    
    if tv_movie=='movie':
        scraper = universalscrapers.scrape_movie
        links_scraper = scraper(
            clean_name(original_title,1),
            show_original_year,
            imdbid,
            timeout=1000,
            exclude=None,
            enable_debrid=allow_debrid)
    else:
     
                scraper = universalscrapers.scrape_episode
                links_scraper = scraper(
                    clean_name(original_title,1),
                    show_original_year,
                    show_original_year,
                    season,
                    episode,
                    imdbid,
                    '',
                    timeout=1000,
                    exclude=None,
                    enable_debrid=allow_debrid)
    for scraper_links in links_scraper():

       if stop_all==1:
         break
       for scraper_link in scraper_links:
        if stop_all==1:
         break
        
        name1,match_s,res,check=server_data(scraper_link['url'],original_title)
        
        if len(res)<2:
          res=scraper_link['quality']
        
        if check :
            all_links.append((name1,scraper_link['url'],match_s,res))
            global_var=all_links
    return global_var