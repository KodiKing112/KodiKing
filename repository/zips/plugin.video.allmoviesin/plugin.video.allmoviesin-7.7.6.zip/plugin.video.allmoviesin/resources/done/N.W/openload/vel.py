# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[108]
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    url='http://ver-pelis.tv/ver/buscar?s='+clean_name(original_title,1).replace(' ','+')
    progress='requests'
    html=requests.get(url,headers=base_header).content
    regex='<h3 class="tit"><a href="(.+?)" title=".+?">(.+?)<'
    progress='Regex'
    match=re.compile(regex).findall(html)
    count=0
    
    for link,name in match:
        progress='Links-'+str(count)
        count+=1
        if clean_name(original_title,1).lower() in name.lower():
            y=requests.get(link,headers=base_header).content
            regex="var dataid=\{id:(.+?),slug:'(.+?)',imdb:'(.+?)'"
            progress='Regex-'+str(count)
            m=re.compile(regex).findall(y)
            id,slug,imdb=m[0]
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                'Referer': link,
                'Accept-Formating': 'application/json, text/javascript',
                'Server': 'cloudflare-nginx',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }

            params = (
                ('id', id),
                ('slug', slug),
                ('imdb', imdb),
            )
            progress='requests-'+str(count)
            y = requests.get('http://ver-pelis.tv/core/api.php', headers=headers, params=params).json()
            print y
            #url2='http://ver-pelis.me/core/api.php?id=%s&slug=%s&imdb=%s'%(id,slug,imdb)
            
            #y=requests.get(url2,headers=base_header).json()
 
            for items in y['lista']:
                progress='links2-'+str(count)
                items_in= y['lista'][items]
                if items_in==None:
                    continue
                if 'subtitulos' in items_in:
                        if isinstance(items_in['subtitulos'], (int, long)):
                            continue
                        if 'video' not in items_in['subtitulos'][0]:
                            continue
                        link2='http://ver-pelis.tv/ajax/verpelis1.php?imdb=tt2231461&video='+ items_in['subtitulos'][0]['video']
                        z=requests.get(link2,headers=base_header).content
                        print link2
                        regex='window.location="(.+?)"'
                        mm=re.compile(regex).findall(z)[0]
                        if '?' in mm:
                           mm=mm.split("?")[0]
                        progress='Check-'+str(count)
                        name1,match_s,res,check=server_data(mm,original_title)
                       
                        print check
                        if check :
                            if res==' ':
                               res='720'
                            all_links.append((name1,mm,match_s,res))
                            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    
    