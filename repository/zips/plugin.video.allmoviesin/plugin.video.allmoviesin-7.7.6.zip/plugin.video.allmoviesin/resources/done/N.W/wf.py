import requests
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s,cloudflare_request

type=['movie']
import urllib2,urllib,logging,base64,json
color=all_colors[76]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all,progress
    all_links=[]
    progress='Start'
    start_time=time.time()
    sUrl=domain_s+'www.uwatchfree.sx/?s=%s&submit=Search'%(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)
    
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    import json,urllib

    progress='Cloud'
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    user_agent="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    x,token=cloudflare_request(sUrl)

    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    progress='requests'
    html= requests.get(sUrl,cookies=token[0],headers=token[1]).content 
    
    regex='<h2 class="entry-title"><a href=(.+?) '
    match=re.compile(regex).findall(html)
  
    from jsunpack import unpack
    count=0
    for items in match:
        print items
        if stop_all==1:
                break
        progress='requests-'+str(count)
        count+=1
        y=requests.get(items,headers=token[1],cookies=token[0]).content 
        
        if 'extramovie.net' in y:
            regex='iframe.+?src="(.+?)"'
            match2=re.compile(regex).findall(y)
            
            headers_ent = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': items,
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }
            
            z = requests.get(match2[0], headers=headers_ent).content
           
            regex='text/javascript">(.+?)</script>'
            match3=re.compile(regex,re.DOTALL).findall(z)
          
            holder = unpack(match3[0])
            regex='"file":"(.+?)"'
            match4=re.compile(regex,re.DOTALL).findall(holder)
            link=match4[0].replace('\\\\/','/')
            ids=link.split('/')
            name1=ids[len(ids)-1].replace('.mp4','')
            if "1080p" in name1:
                        res="1080"
            elif "720p" in name1:
                    res="720"
            elif "480p" in name1:
                    res="720"
            elif "hd" in name1.lower():
                    res="HD"
            else:
                    res=' '
            headers2 = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': match2[0],
            'Range': 'bytes=13402112-',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            }
            head=urllib.urlencode(headers2)
            link=link+"|"+head
            all_links.append((name1,link,'Direct',res))
            global_var=all_links
        else:
         
         
          regex="doit\('(.+?)'"
          match3=re.compile(regex,re.DOTALL).findall(y)
         
          if len(match3)>0:
              match3=match3[0].decode('base64').decode('base64')
              regex='iframe.+?src="(.+?)"'
              match2=re.compile(regex).findall(match3)
             
              nam1,srv,res,check=server_data(match2[0],original_title)
                      
              if check:
                    all_links.append((nam1.replace("%20"," "),match2[0],srv,res))
                    global_var=all_links
          else:
          
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': items,
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }
            regex='iframe src=(.+?) '
            match3=re.compile(regex).findall(y)
           
            try:
                response = requests.get(match3[0], headers=headers,timeout=5).content
                
                regex='script type="text/javascript">(.+?)</script>'
                match4=re.compile(regex,re.DOTALL).findall(response)
                holder = unpack(match4[0])
                regex='"file":"(.+?)".+?"label":"(.+?)"'
                macth=re.compile(regex,re.DOTALL).findall(holder)
               
                for link,name in macth:
               
                   if stop_all==1:
                        break
                   if 'dubbed' not in link:
                    split_link=link.split('/')
                    name1=split_link[len(split_link)-1].replace('.mp4','').replace('.mkv','').replace('.avi','')
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                        'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': match3[0],
                        
                        'Connection': 'keep-alive',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                        'TE': 'Trailers',
                    }
                    head=urllib.urlencode(headers)
                     #ht=requests.get(url,headers=headers).content
                    url=link.replace('\\\\','\\').replace('\/','\\').replace('\\','/')
                    url=url+"|"+head
                     
                    all_links.append((name1.replace("%20"," "),url,'Mega',name))
                    global_var=all_links
            except:
                pass
     
           
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links





