# -*- coding: utf-8 -*-
#taken from Mega shows apk
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[2]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    #import cfscrape
    all_links=[]
    url='http://mindgeek.in/api/get_search_results/?api_key=new11uT8cBLzm6a1YvsiUWOEgrFowk95K2DM3tHAPRCX4ypGjN&search=%s&count=100'%(original_title)
    headers={'Cache-Control': 'max-age=0',
            'Data-Agent': 'The Stream',

            'Connection': 'Keep-Alive',

            'User-Agent': 'okhttp/3.14.1'}
    progress='requests'
    x=requests.get(url,headers=headers).json()
    for items in x['posts']:
        check=False
        if 'Hindi' not in items['category_name']:
            if tv_movie=='tv':
  
                if items['channel_name']=='Season %s - Episode %s'%(season,episode):
                    check=True
            else:
                check=True
            if check:
                if '1080' in items['channel_name']:
                    res='1080'
                elif '720' in items['channel_name']:
                    res='720'
                elif '480' in items['channel_name']:
                    res='480'
                else:
                    res='720'
                s_name='Direct'
                try:
                    try_head = requests.get(items['channel_url'],headers=headers, stream=True,verify=False,timeout=10)
                    f_size2='0.0 GB'
       
                    if 'Content-Length' in try_head.headers:
                       if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Direct'+' - '+f_size2
                    else:
                        s_name='Direct'
                except:
                    pass
                all_links.append((original_title,items['channel_url'],s_name,res))
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            