# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,os
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header,Addon
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    dataPath = os.path.dirname(os.path.realpath(__file__))
    mypath=os.path.join(dataPath,'cache_f')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    all_links=[]
    progress='DB'
    tmdb_cacheFile = os.path.join(mypath, 'one2.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    if tv_movie=='tv':
       dbcur_tmdb.execute("SELECT * FROM tv_movie WHERE (name like '%{0}%' or name like '%{1}%') and (season='{2}' or season='{3}') and (episode='{4}' or episode='{5}')".format(clean_name(original_title,1).replace('.',' ').replace("'","%27").lower(),clean_name(original_title,1).replace(' ','.').replace("'","%27").lower(),season_n,season,episode_n,episode))
    else:
        dbcur_tmdb.execute("SELECT * FROM tv_movie WHERE name like '%{0}%' or name like '%{1}%'".format(clean_name(original_title,1).replace('.',' ').replace("'","%27").lower(),clean_name(original_title,1).replace(' ','.').replace("'","%27").lower()))
   
    
    match4 = dbcur_tmdb.fetchall()
    
    count=0
    for eng_name,link,season,episode,size,type in match4:
        progress='Links-'+str(count)
        count+=1
      
        names=link.split('/')
        name1=names[len(names)-1]
        name1=eng_name
        if '2160' in name1:
              res='2160'
        elif '4k' in name1.lower():
              res='2160'
        elif '1080' in name1:
              res='1080'
        elif '720' in name1:
              res='720'
        elif '480' in name1:
              res='480'
        elif '360' in name1:
              res='360'
        else:
              res='720'
        
              
        all_links.append((name1,urllib.unquote_plus(link).replace(' ','%20'),'- Direct - '+str(size),res))
        global_var=all_links
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    
    return all_links
