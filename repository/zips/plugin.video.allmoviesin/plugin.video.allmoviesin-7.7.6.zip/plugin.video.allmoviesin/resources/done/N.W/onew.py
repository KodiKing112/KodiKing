# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,os
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header,Addon
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    all_links=[]
   
    start_time=time.time()
    if tv_movie=='movie':
        if int(show_original_year)>=1900 and int(show_original_year)<=1999:
            url='http://103.115.24.6/data/Movies/Hollywood/1900-1999/'
        elif int(show_original_year)>=2000 and int(show_original_year)<=2010:
            url='http://103.115.24.6/data/Movies/Hollywood/2000-2010/'
        elif int(show_original_year)>=2011 and int(show_original_year)<=2015:
            url='http://103.115.24.6/data/Movies/Hollywood/2011-2015/'
        elif int(show_original_year)==2016:
            url='http://103.115.24.6/data/Movies/Hollywood/2016/'
        elif int(show_original_year)==2017:
            url='http://103.115.24.6/data/Movies/Hollywood/2017/'
        elif int(show_original_year)==2018:
            url='http://103.115.24.6/data/Movies/Hollywood/2018/'
        else:
            url='http://103.115.24.6/data/Movies/Hollywood/English_2019/'
        
        x=requests.get(url,headers=base_header).content
        regex='<td class="link"><a href="(.+?)" title="(.+?)"'
        m=re.compile(regex).findall(x)
        for lk,nm in m:
            if not( clean_name(original_title,1).lower() in nm.lower() and show_original_year in nm):
                continue
            
            y=requests.get(url+lk,headers=base_header).content
            regex='tr><td class="link"><a href="(.+?)"'
            m2=re.compile(regex).findall(y)
            for it in m2:
                
                if '.mp4' not in it and '.avi' not in it and '.mkv' not in it:
                    continue
                try_head = requests.head(url+lk+it,headers=base_header, stream=True,verify=False,timeout=15)
                
                size='0'
                if 'Content-Length' in try_head.headers:
                  
                        if int(try_head.headers['Content-Length'])>(1024*1024):
                            f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                        if f_size2!='0.0 GB':
                            size=f_size2
                        else:
                            size='0'
                if '2160' in it:
                      res='2160'
                elif '4k' in it.lower():
                      res='2160'
                elif '1080' in it:
                      res='1080'
                elif '720' in it:
                      res='720'
                elif '480' in it:
                      res='480'
                elif '360' in it:
                      res='360'
                else:
                    res='720'
                t=lk.split('/')
                title=t[len(t)-1].replace('/','')
                all_links.append((clean_name(it,1),url+lk+it,'- Direct - '+str(size),res))
                global_var=all_links
    else:
        
        url='http://103.115.24.6/data/TV%20Series/English%20TV%20Shows/'
        
        x=requests.get(url,headers=base_header).content
        regex='<td class="link"><a href="(.+?)" title="(.+?)"'
        m=re.compile(regex).findall(x)
        for lk,nm in m:
           
            if nm.lower().strip()!=clean_name(original_title,1).lower() and (nm.lower()).strip()!=(clean_name(original_title,1).lower()+' (%s)'%show_original_year):
                continue
           
            url2=url+lk+'Season%20'+season+'/'
            
            x=requests.get(url2,headers=base_header).content
            regex='<td class="link"><a href="(.+?)"'
            m2=re.compile(regex).findall(x)
            for it in m2:
           
                regex=' Season (\d\d?) Episode (\d\d?) '
                m3=re.compile(regex,re.IGNORECASE).findall(it)
                if len(m3)==0:
                    regex='S(\d\d?)(?:.|)E(\d\d?)'
                    m3=re.compile(regex,re.IGNORECASE).findall(it)
               
                if len(m3)==0:
                   regex='(\d\d?)x(\d\d?)'
                   m3=re.compile(regex,re.IGNORECASE).findall(it)
                if len(m3)==0:
                    continue
                season_m3=m3[0][0]
    
                episode_m3=m3[0][1]
                if episode_m3!=episode_n and episode_m3!=episode:
                    continue
                try_head = requests.head(url2+it,headers=base_header, stream=True,verify=False,timeout=15)
               
                size='0'
                if 'Content-Length' in try_head.headers:
                  
                        if int(try_head.headers['Content-Length'])>(1024*1024):
                            f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                        if f_size2!='0.0 GB':
                            size=f_size2
                        else:
                            size='0'
                if '4k' in it.lower():
                      res='2160'
                elif '2160' in it:
                      res='2160'
                elif '1080' in it:
                      res='1080'
                elif '720' in it:
                      res='720'
                elif '480' in it:
                      res='480'
                elif '360' in it:
                      res='360'
                else:
                      res='720'
                
                all_links.append((clean_name(it,1),url2+it,'- Direct - '+str(size),res))
                global_var=all_links
    return all_links
