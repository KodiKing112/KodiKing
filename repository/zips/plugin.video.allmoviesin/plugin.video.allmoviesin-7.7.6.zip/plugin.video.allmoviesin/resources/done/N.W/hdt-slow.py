# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[99]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
      search_string=clean_name(original_title,1).replace(' ','+')+'+season+'+season
    else:
      search_string=clean_name(original_title,1).replace(' ','+')

    progress='Cloud'
    header,token=cloudflare_request('http://www3.hd.today/search-movies')
    
    x=requests.get('http://www3.hd.today/search-movies/%s.html'%(search_string),headers=token[1],cookies=token[0]).content
 
    regex='<div class="ml-item">(.+?)</span>'
    progress='Regex'
    match_pre=re.compile(regex,re.DOTALL).findall(x)
    
    count=0
    for items in match_pre:
     progress='Links-'+str(count)
     count+=1
     regex='<a href="(.+?)".+?<h2>(.+?)</h2>'
     match=re.compile(regex,re.DOTALL).findall(items)
     for link,name in match:
        progress='Links2-'+str(count)
 
        if stop_all==1:
           break
        check=False
        if clean_name(original_title,1).lower()==name.lower() and tv_movie=='movie':
          check=True
        elif clean_name(original_title,1).lower() in name.lower() and tv_movie=='tv':
          check=True
    
        if check:
            progress='requests-'+str(count)
            y=requests.get(link,headers=token[1],cookies=token[0]).content
            if tv_movie=='tv':
                regex='class="episode episode_series_link" href="(.+?)">(.+?)</a>'
                match_ep=re.compile(regex).findall(y)
                f_link=''
                for links_in1,ep in match_ep:
                    if episode==ep:
                      f_link=links_in1
               
                if f_link=='':
                    break
                progress='requests2-'+str(count)
                y=requests.get(f_link,headers=token[1],cookies=token[0]).content
            regex='<p class="server_play"><a href="(.+?)"'
            match_se=re.compile(regex).findall(y)
            
            regex='Base64.decode\("(.+?)"'
            match2=re.compile(regex).findall(y)
            links=match2[0].decode('base64')
            regex='src="(.+?)"'
            
            match_l=re.compile(regex).findall(links)[0]
            if 'entervideo' in match_l:
                    y=requests.get(match_l,headers=base_header).content
                    regex='source src="(.+?)"'
                    f_link=re.compile(regex).findall(y)
                    
                    
                    names=f_link[0].split('/')
     
                    name1=names[len(names)-1]
                    if "1080" in name1:
                        res="1080"
                    elif "720" in name1:
                        res="720"
                    elif "480" in name1:
                        res="720"
                    elif "hd" in name1.lower():
                        res="HD"
                    else:
                       res=' '
                    headers2 = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Host': 'entervideo.net',
                    'Pragma': 'no-cache',
                    'Referer':match_l,
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                    }
                    head=urllib.urlencode(headers2)
                    try_head = requests.get(f_link[0],headers=headers2, stream=True,verify=False,timeout=10)
                  
                    f_size2='0.0 GB'
                    if 'Content-Length' in try_head.headers:
                       if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                   
                    f_s=''
                    if f_size2!='0.0 GB':
                        f_s=' - '+f_size2
                    all_links.append((name1,f_link[0]+"|"+head,'Direct'+f_s,res))
                    global_var=all_links
            else:
                progress='Check-'+str(count)
                name1,match_s,res,check=server_data(match_l,original_title)
                        
                
                if check :
                    all_links.append((name1,match_l,match_s,res))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var