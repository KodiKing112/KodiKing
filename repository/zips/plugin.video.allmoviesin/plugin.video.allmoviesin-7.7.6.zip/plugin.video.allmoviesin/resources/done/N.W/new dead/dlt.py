import requests,time
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']
color=all_colors[18]
import urllib2,urllib,logging,base64,json
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
   
    import random
    all_links=[]
    if tv_movie=='tv':
      
      url=domain_s+'www3.tornadomovies.co/search_all/~%s~'%((original_title)+'%20season%20'+season)
    else:
      url=domain_s+'www3.tornadomovies.co/search_all/~%s~'%(original_title+'%20'+show_original_year)
    
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    html=requests.get(url,headers=headers).content
    
    regex_pre='<div class="block_placeholder">(.+?)<div class="title '
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    headers_o=headers
    
    for items in match_pre:
       
        if stop_all==1:
            break
        regex='data-href="(.+?)".+?data-name="(.+?)".+?data-year="(.+?)"'
        
        match=re.compile(regex,re.DOTALL).findall(items)
        all_link_a=[]
        
        for link,name,year in match:
          check=False
          if tv_movie=='movie':
           
            if show_original_year == year:
              check=True
     
          else:

            if 'Season '+season in name:
              check=True
             
          
        
          
          if clean_name(original_title,1).lower() in name.lower().replace(':','') and check:
            xx=requests.get(domain_s+'www1.tornadomovies.to'+link,headers=headers_o).content
            
            regex='data-ep-id="(.+?)".+?a href="(.+?)".+?title="(.+?)"'
            match2=re.compile(regex,re.DOTALL).findall(xx)
    
            regex='id="m_info" data-id="(.+?)"'
            
            showid=re.compile(regex).findall(xx)[0]
            
            if tv_movie=='movie':
              yy=requests.get(domain_s+'www1.tornadomovies.to/user/serverlist/%s?ep=%s'%(showid,'0'),headers=headers).content
              regex='li class="point serverPoint.+?" data-value="(.+?)" data-server="(.+?)"'
              match3=re.compile(regex).findall(yy)
             
              for value,server in match3:
                    if stop_all==1:
                        break
                    headers = {
                        'pragma': 'no-cache',
                        
                        'accept-encoding': 'utf8',
                        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
                        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
                        'accept': 'application/json, text/javascript, */*; q=0.01',
                        'cache-control': 'no-cache',
                        'authority': 'www1.tornadomovies.to',
                        'x-requested-with': 'XMLHttpRequest',
                        'referer': domain_s+'www1.tornadomovies.to'+link,
                    }

                    params = (
                        ('number', value),
                        ('r', str(random.uniform(0.1, 0.4))),
                        ('_', str(time.time())),
                        ('server',server)
                    )
                    params = {
                        'number':server,
                        'r':str(random.uniform(0.1, 0.4)),
                        '_':str(time.time()),
                        'server':value
                    }
                    
                    response = requests.get(domain_s+'www1.tornadomovies.to'+link+'?'+urllib.urlencode(params), headers=headers).content
                    response=json.loads(response)
                    
                    for result in response:
                  
                      if stop_all==1:
                            break
                      if 'link' in response:
                         name1,match_s,res,check=server_data(response['link'],original_title)
                         if check:
                           all_links.append((name1,response['link'],match_s,res))
                           global_var=all_links
                      else:
                          if 'label' in result:
                            res=result['label']
                          else:
                            res=' '
                          if 'src'  in result:
                            
                              all_links.append((name,result['src'],'Direct',res))
                              global_var=all_links
            else:
             for id,link2,title in match2:
              
              
              if 'season %s episode %s'%(season,episode_n) in title.lower():
                
                
                yy=requests.get(domain_s+'www1.tornadomovies.to/user/serverlist/%s?ep=%s'%(showid,'0'),headers=headers).content
                regex='li class="point serverPoint.+?" data-value="(.+?)" data-server="(.+?)"'
                match3=re.compile(regex).findall(yy)
                
                for value,server in match3:
                    headers = {
                        'pragma': 'no-cache',
                        
                        'accept-encoding': 'utf8',
                        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
                        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
                        'accept': 'application/json, text/javascript, */*; q=0.01',
                        'cache-control': 'no-cache',
                        'authority': 'www1.tornadomovies.to',
                        'x-requested-with': 'XMLHttpRequest',
                        'referer': domain_s+'www1.tornadomovies.to'+link2,
                    }

                    params = (
                        ('number', value),
                        ('r', str(random.uniform(0.1, 0.4))),
                        ('_', str(time.time())),
                        ('server',server)
                    )
                    params = {
                        'number':server,
                        'r':str(random.uniform(0.1, 0.4)),
                        '_':str(time.time()),
                        'server':value
                    }
                   
                    response = requests.get(domain_s+'www1.tornadomovies.to'+link2+'?'+urllib.urlencode(params), headers=headers).content
                    response=json.loads(response)
                    
                    for result in response:
                      
                      if 'link' in response:
                         name1,match_s,res,check=server_data(response['link'],original_title)
                         if check:
                           all_links.append((name1,response['link'],match_s,res))
                           global_var=all_links
                      elif 'src' in result:
                          if 'label' in result:
                            res=result['label']
                          else:
                            res=' '
                          all_links.append((original_title,result['src'],'Direct',res))
                          global_var=all_links
    return all_links