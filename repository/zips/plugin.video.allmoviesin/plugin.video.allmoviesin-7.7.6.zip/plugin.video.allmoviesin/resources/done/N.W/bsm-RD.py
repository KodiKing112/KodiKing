# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,parseDOM,rd_domains
type=['movie','rd']

import urllib2,urllib,logging,base64,json

color=all_colors[91]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]
    base_link = 'https://www.best-moviez.ws/'
    search_link = '/%s'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'search.rlsbb.ru:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
    x,cook=cloudflare_request(base_link,headers=headers)
   
    title = clean_name(original_title,1)

   
    if tv_movie=='movie': 
       query='%s-%s' % (title, show_original_year)
    else:
    
      query = '%s-s%se%s' % (title, season, episode) 
   

    url = '/%s' % urllib.quote_plus(query)
    url = urlparse.urljoin(base_link, url)
    #log_utils.log('\n\n\n\n\n\nquery, url: %s, %s' % (query,url))
   
    r = requests.get(url,headers=cook[1],cookies=cook[0]).content

    print url
    # grab the (only?) relevant div and cut off the footer
    r = parseDOM(r, "div", attrs={'class': 'entry-content'})[0]
    r = re.sub('shareaholic-canvas.+', '', r, flags=re.DOTALL)


            
    # gather actual <a> links then clear all <a>/<img> to prep for naked-url scan
    # inner text could be useful if url looks like http://somehost.com/ugly_hash_377cbc738eff
    a_txt = ''
    a_url = ''
    a_txt = parseDOM(r, "a", attrs={'href': '.+?'})
    a_url = parseDOM(r, "a", ret = "href")
    r = re.sub('<a .+?</a>', '', r, flags=re.DOTALL)
    r = re.sub('<img .+?>', '', r, flags=re.DOTALL)	
    

    # check pre blocks for size and gather naked-urls
    size = ''			
    pre_txt = []
    pre_url = []
    pres = parseDOM(r, "pre", attrs={'style': '.+?'})
 
    for pre in pres:
        try: size = re.findall('([0-9,\.]+ ?(?:GB|GiB|MB|MiB))', pre)[0]
        except: pass
        
        url0 = re.findall('https?://[^ <"\'\s]+', pre, re.DOTALL) # bad form but works with this site
        txt0 = [size] * len(url0)
        pre_url = pre_url + url0
        pre_txt = pre_txt + txt0 # we're just grabbing raw urls so there's no other info
        
    r = re.sub('<pre .+?</pre>', '', r, flags=re.DOTALL)	

    
    # assume info at page top is true for all movie links, and only movie links
    #  (and that otherwise, only <pre>'s have scrapable sizes)
    size = ''
    if tv_movie=='movie':
        try: size = " " + re.findall('([0-9,\.]+ ?(?:GB|GiB|MB|MiB))', r)[0]
        except: pass

    
    # get naked urls (after exhausting <a>'s and <pre>'s)
    # note: all examples use full titles in links, so we can be careful
    raw_url = re.findall('https?://[^ <"\'\s]+', r, re.DOTALL) # bad form but works with this site
    raw_txt = [size] * len(raw_url) # we're just grabbing raw urls so there's no other info

    
    # combine the 3 types of scrapes
    pairs = zip(a_url+pre_url+raw_url, a_txt+pre_txt+raw_txt)
  
    all_links=[]
 
    for pair in pairs:
        
            url = str(pair[0])
            
            if  '.rar' not in url and '.zip' not in url and '.iso' not in url:
                host = url.replace("\\", "")
                host2 = host.strip('"')
                host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
              
                #if host not in rd_domains:
                #    continue
                
                names=url.split('/')
                name1=names[len(names)-1]
                if '1080' in name1:
                      res='1080'
                elif '720' in name1:
                      res='720'
                elif '480' in name1:
                      res='480'
                elif '360' in name1:
                      res='360'
                else:
                      res='480'
          
                #name1,match_s,res,check=server_data(link,original_title,direct='rd')
             
                if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                    check=True
                else:
                    check=False
                print check
                if 'openload' in url or 'streamango' in url:
                    name1,match_s,res,check=server_data(url,original_title)
                  
                if check :
                    if '.rar' not in name1:
                        all_links.append((name1,url,host,res))
                        global_var=all_links
    return global_var
                
                