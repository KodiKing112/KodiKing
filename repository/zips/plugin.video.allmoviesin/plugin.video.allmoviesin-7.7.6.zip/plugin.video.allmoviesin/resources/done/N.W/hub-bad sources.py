# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[32]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all

    all_links=[]

    url='http://hubmovie.cc/pages/search2/'+(clean_name(original_title,1).replace(' ','+'))
    
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    html=requests.get(url,headers=headers).content
    regex_pre='<div class="row featured">(.+?)<div class=\'under_embedded'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    
    for items in match_pre:
       if stop_all==1:
           break
       regex='<a href="(.+?)">.+?<h1>(.+?)</h1>.+?tag_color\'>(.+?)<'
       match=re.compile(regex,re.DOTALL).findall(items)
     
       for link,name_in,year in match:
          if stop_all==1:
                    break
          if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in year:
             
             y=requests.get(link.replace('./','http://hubmovie.cc/'),headers=headers).content
             if tv_movie=='tv':
                y=requests.get(link.replace('./','http://hubmovie.cc/')+'/season-%s-episode-%s'%(season_o,episode_o),headers=headers).content
                
               
             regex_p="onclick=.+?'(.+?)'"
             match_p=re.compile(regex_p).findall(y)

             if len(match_p)==0:
                regex_p='embed-responsive-item" SRC="(.+?)"'
                match_p=re.compile(regex_p).findall(y)
              
                nam1,srv,res,check=server_data(match_p[0],original_title)
                print match_p[0]
                if check:
                    all_links.append((nam1.replace("%20"," ").replace("-",""),match_p[0],srv,res))
                    global_var=all_links
             else:
                 for items in match_p:
                    if stop_all==1:
                        break
                    headers = {
                        'Pragma': 'no-cache',
                        'Origin': 'http://hubmovie.cc',
                        'Accept-Encoding': 'gzip, deflate',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'Accept': 'application/json, text/javascript, */*; q=0.01',
                        'Cache-Control': 'no-cache',
                        'X-Requested-With': 'XMLHttpRequest',
                        'Connection': 'keep-alive',
                       
                    }

                    data = [
                      ('goto', items),
                    ]

                    response = requests.post('http://hubmovie.cc/ajax/goTo.php', headers=headers, data=data).json()
                    
                    
                    nam1,srv,res,check=server_data(response['return'],original_title)
                      
                    if check:
                        all_links.append((nam1.replace("%20"," "),response['return'],srv,res))
                        global_var=all_links
    return all_links