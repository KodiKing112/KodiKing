import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors


import urllib2,urllib,logging,base64,json

type=['movie','tv']
color=all_colors[28]
def get_putvid(url):
    z=requests.get(url).content

    regex="return p.+?'(.+?)'\.split"
    str_new=re.compile(regex).findall(z)[0]
    pre=''
    x=0
    for ch in str_new:
       
       if ch=="'" and pre!='\\':
         loc=x
         break
       else:
        pre=ch
        x=x+1
    p=(str_new[0:x])
    rest=(str_new.replace(p,""))
    a=int(rest.split(',')[1])
    c=int(rest.split(',')[2])-1
    k=rest.split(',')[3].split('|')
    p=p.replace('\\','')


    while (c>0):
        
        if (k[c]):
          temp=(base_convert(c,a))
          p=re.sub("\\b"+(base_convert(c,a))+"\\b", k[c], p)
          
        c=c-1
    regex='http(.+?)"'
    match=re.compile(regex).findall(p)
 
    return 'http'+match[0]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    import js2py
    from js2py.internals import seval
    if tv_movie=="tv":
    
       name_search=original_title.lower().replace(" ","-").replace("%20","-").replace("%3a","").replace("%27","-")+"/"+season_n+"-"+episode_n
       htm=requests.get("http://gomo.to/show/"+name_search).content
    else:
       name_search=original_title.lower().strip().replace(" ","-").replace("%20","-").replace("%3a","").replace("%27","-")
       htm=requests.get("http://gomo.to/movie/"+name_search).content
    progress='Regex'
   
    regex="var tc = '(.+?)'"
    match2=re.compile(regex,re.DOTALL).findall(htm)
    regex='function _tsd_tsd_ds(.+?)</script>'
    match=re.compile(regex).findall(htm)
    jscode="var s = '%s';tc=_tsd_tsd_ds(s);"%match2[0]+'function _tsd_tsd_ds'+match[0]

    progress='seval'
    result=seval.eval_js_vm(jscode)
    
    regex='"_token": "(.+?)"'
    match3=re.compile(regex).findall(htm)

    headers= { 
    'Accept': '*/*',
    'Accept-Encoding': 'utf-8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Length': '282',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Host': 'gomo.to',
    'Pragma': 'no-cache',
    'x-token': result
    }
    data= {
      'tokenCode': match2[0],
      "_token": match3[0],
    }
    progress='requests'
    x=requests.post("https://gomo.to/decoding_v3.php",headers=headers,data=data).json()
    
    all_links=[]
  
    
    for link in x:
      
      if stop_all==1:
          break
      if 'putvid' in link:
 
        link=get_putvid(link)
        all_links.append((original_title.replace("%20"," "),link,"PUTVID","1080"))
          
        global_var=all_links
      elif 'fbcdn' in link:
   
         all_links.append((original_title.replace("%20"," "),link,"Direct","1080"))
          
         global_var=all_links
      elif 'vidushare.com' not in link and len(link)>5:#try:
          try:
            html2=requests.get(link,stream=True).url
          except:
            continue
     
          #regex='"og:title" content="(.+?)"'
          #match=re.compile(regex).findall(html2)
       
          
          name1=original_title
          res=' '
          
          name2,match_s,res2,check=server_data(html2,original_title)
          if check:
              all_links.append((name2.replace("%20"," "),html2,match_s,res2))
              
              global_var=all_links
  
        
    
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links