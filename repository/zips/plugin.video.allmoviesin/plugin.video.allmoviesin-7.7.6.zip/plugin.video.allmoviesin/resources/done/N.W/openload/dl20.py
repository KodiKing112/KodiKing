import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['movie','tv']
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        start_time=time.time()

        url='http://watchmoviestream.me/'
        
        progress=' Start '
        all_links=[]
        headers = {
            'Host': 'watchmoviestream.me',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            #'Referer': domain_s+'watchmoviestream.me/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        params = (
            ('s', original_title.replace('%20','+').replace(' ','+').replace('%3a',':').replace('%27','+')),
        )
        url='https://watchmoviestream.me/?s='+original_title.replace('%20','+').replace(' ','+').replace('%3a',':').replace('%27','+')
        
        progress=' cloud '
        response,cook=cloudflare_request(url)
       
        #response = requests.get(domain_s+'watchmoviestream.me/', headers=headers, params=params).content
        regex='<div class="title"><a href="(.+?)">(.+?)<'
        progress='Regex'
        match=re.compile(regex).findall(response)
        count=0
        
        for link,name in match:
         
         progress=' Links - '+str(count)
         count+=1
         if stop_all==1:
             break
         if 1:#try:
          check=False
          
          if tv_movie=='movie':
             if show_original_year in name:
              check=True
          else:
            check=True
       
          if original_title.lower().replace('%20',' ').replace('3a',':').replace('%27',"'") in name.replace("&#8217;","'").lower():
            progress=' Req2 - '+str(count)
            yy=requests.get(link, headers=cook[1],cookies=cook[0]).content
            f_link=link
            if tv_movie=='tv':
              regex="div class='numerando'>%s - %s</div><div class='episodiotitle'><a href='(.+?)'>"%(season,episode)
              
              match2=re.compile(regex).findall(yy)
              
              if len(match2)==0:
                continue
              progress=' req3 - '+str(count)
              zz=requests.get(match2[0], headers=cook[1],cookies=cook[0]).content
              f_link=match2[0]
              
            else:
              if show_original_year not in name:
                continue
              zz=yy
            
            regex='show=(.+?)"'
            
            match3=re.compile(regex).findall(zz)
            
            if len (match3)>0:
                match3=match3[0].decode('base64')
                progress=' req4 - '+str(count)
                xx=requests.get(match3, headers=cook[1],cookies=cook[0]).content
                regex='"og:title" content="(.+?)"'
                match4=re.compile(regex).findall(xx)
                if len(match4)>0:
                      name1=match4[0]
                      try:
                          info=(PTN.parse(match4[0]))
                          
                          if 'resolution' in info:
                             res=info['resolution']
                          else:
                             if "HD" in match4[0]:
                              res="HD"
                             elif "720" in match4[0]:
                              res="720"
                             elif "1080" in match4[0]:
                               res="1080"
                             else:
                               res=' '
                      except:
                        res=' '
                        pass
                else: 
                    name1=original_title
                    res=' '
                regex_s="//(.+?)/"
                match_s=re.compile(regex_s).findall(match3)
                all_links.append((name1.replace("%20"," "),match3,match_s[0],res))
           
                global_var=all_links
            regex="<li id='player-option-(.+?)>"
            
            match3=re.compile(regex).findall(zz)
            count2=0
            for pre in match3:
                print pre
                progress=' Links2 - '+str(count2)
                count2+=1
                regex="data-type='(.+?)' data-post='(.+?)' data-nume='(.+?)'"
               
                match4=re.compile(regex).findall(pre)
                if len(match4)==0:
                    continue
                type,nume,post=match4[0]
               
               
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer':f_link ,
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }

                data = {
                  'action': 'doo_player_ajax',
                  'post': nume,
                  'nume':  post,
                  'type': type
                }
                progress=' Req5 - '+str(count2)
                response ,cook=cloudflare_request('https://watchmoviestream.me/wp-admin/admin-ajax.php',post=data)
                
                
                regex="src='(.+?)'"
                match3=re.compile(regex).findall(response)[0]
                nam1,srv,res,check=server_data(match3,original_title)
                
                if check:
                        all_links.append((nam1.replace("%20"," "),match3,srv,res))
                        global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links