# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[107]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'https://www.filmxy.me'
    search = '/?s='
    search_id=clean_name(original_title,1)
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'TE': 'Trailers',
    }

    params = (
        ('export', 'view'),
        ('id', '1KFd0jUkTXKwxA4VAxXmfYze6zZG8djwr'),
    )
    progress='requests'
    #r = requests.get('https://drive.google.com/uc', headers=headers, params=params).content
    response=requests.get('https://raw.githubusercontent.com/Teatvandroid/TeaTV_Android/master/posts.json',headers=headers).json()
    #response=json.loads(r.split('=')[1].decode('unicode_escape'))
  

    count=0
    for items in response:
        progress='Links-'+str(count)
        count+=1
        name=items['name']
        item_url=items['link']
        
    
        if '(' in name:
            

            release=name.split('(')[-1].split(')')[0]

            name=name.split('(')[0]

       
        
        if not show_original_year == release:

            continue
        

        

        if search_id.lower() in name.lower():
            progress='requests2-'+str(count)
            print item_url
            OPEN = requests.get(item_url,headers=base_header).content
            regex='iframe src=&quot;(.+?)&quot;'
            match=re.compile(regex,re.IGNORECASE).findall(OPEN)
            print match
            for link in match:
                progress='Check-'+str(count)
                name2,match_s,res,check=server_data(link,original_title)
                
                if check:

                    all_links.append((name2.replace('[Filmxy.One]','').strip(),link,match_s,res))
                    
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
            