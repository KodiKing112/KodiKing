
import requests,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header

type=['tv','movie']
import urllib2,urllib,logging,base64,json
color=all_colors[13]


def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
        search_str=clean_name(original_title,1).lower()+'%20season%20'+season
    else:
        search_str=clean_name(original_title,1).lower()+'%20'+show_original_year
        
    x=requests.get('https://www.putlockers.cr/search/%s/'%search_str,headers=base_header).content

    regex='<div class="ml-item">(.+?)</a>'
    m=re.compile(regex,re.DOTALL).findall(x)
    for items in m:
        if stop_all==1:
                break
        regex='cid="(.+?)".+?<h2>(.+?)</h2>'
        m2=re.compile(regex,re.DOTALL).findall(items)
        
        m3=[]
        if '(' in m2[0][1]:
            reg='\((.+?)\)'
            m3=re.compile(reg).findall(m2[0][1])
            if tv_movie=='tv':
                nam=m2[0][1].replace(' (%s)'%m3[0],'')
            else:
                nam=m2[0][1]
        else:
            nam=m2[0][1]
        cmp_str=(clean_name(original_title,1)+' - Season '+season).lower()
        if tv_movie=='movie':
            if len(m3)>0:
                cmp_str=(clean_name(original_title,1)+' (%s)'%m3[0]).lower()
            else:
                cmp_str=(clean_name(original_title,1)).lower()
   
       
        if nam.lower()==cmp_str:
           
            y=requests.get('https://www.putlockers.cr'+ m2[0][0],headers=base_header).content
            if tv_movie=='movie':
                regex='data-file="(.+?)"'
            else:
                regex='title="Episode %s: .+?data-file="(.+?)"'%episode_n
            m4=re.compile(regex).findall(y)
            for items_i in m4:
                
                name1,match_s,res,check=server_data(items_i,original_title)
          
              
                
                if check :
                    all_links.append((name1,items_i,match_s,res))
                    global_var=all_links
            
            
    
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    