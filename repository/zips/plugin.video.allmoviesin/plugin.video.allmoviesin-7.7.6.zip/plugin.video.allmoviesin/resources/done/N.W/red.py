# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[54]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all

        all_links=[]

        url=domain_s+'www.reddit.com/r/fullmoviesonopenload/search?q=%s&restrict_sr=1'%(clean_name(original_title,1).replace(' ','+'))

        headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'utf8',
              

                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'}
  
        html=requests.get(url,headers=headers).content
        regex_pre='<span style="font-weight:normal">(.+?)</h2>.+?href="(.+?)"'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(html)

        all_link=[]

        for name_in,link in match_pre:
              if stop_all==1:
                    break
              if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in name_in:
                        if link not in all_link:
                            all_link.append(link)
                            nam1,srv,res,check=server_data(link,original_title)
                           
                            if check:
               
                                all_links.append((nam1.replace("%20"," "),link,srv,res))
                                global_var=all_links
        return all_links