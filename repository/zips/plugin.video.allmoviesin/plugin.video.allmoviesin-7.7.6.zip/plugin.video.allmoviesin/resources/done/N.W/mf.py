# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[39]
global res2
res2=' '
def get_ganol(url,original_title):
        global res2
        global stop_all
        from general import server_data
        from jsunpack import unpack
        headers = {
        #'Host': 'ganool.im',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        #'Referer': 'https://ganool.im/?s=black+panther',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        x=requests.get(url+'/watch.html',headers=headers).content
        regex='<li class="recordtype">(.+?)<'
        q=re.compile(regex,re.DOTALL).findall(x)
        for items in q:
            if "1080" in items:
                res2="1080"
            elif "720" in items:
                res2="720"
            elif "480" in items:
                res2="720"
            elif "hd" in items.lower():
                res="HD"
            else:
                res2=' '
        
        regex='<div class="movieplayserver">(.+?)</div>'
        m_pre=re.compile(regex,re.DOTALL).findall(x)[0]
        regex='<a href="(.+?)"'
        m=re.compile(regex).findall(m_pre)
        names_urls=[]
        urls=[]
        resolvea=[]
        m.append(url+'/watch.html')
        for items in m:
            
            if 'javascrip' in items:
                continue
            
            x=requests.get(items,headers=headers).content
            regex='iframe.+?src="(.+?)"'
            match=re.compile(regex,re.IGNORECASE).findall(x)
            
            
            for item in match:
             
              if stop_all==1:
                        break
              if 'blazefile.co' in item:
                 try:
                     
                     y=requests.get(item).content
                     regex="type='text/javascript'>(.+?)<"
                     match_in=re.compile(regex,re.DOTALL).findall(y)
                     temp=unpack(match_in[0])
               
                     regex_link='file:"(.+?)"'
                     match_link=re.compile(regex_link).findall(temp)[0]
                     regex_n='//(.+?)/'
                     match_n=re.compile(regex_n).findall(match_link)[0]
                     names_urls.append(match_n)
                     urls.append(match_link)
                     resolvea.append(False)
                 except:
                  pass
              elif 'ganol' in item:
              
                x=requests.get(item,headers=headers).content
                regex='</div><script type="text/javascript">(.+?)</script>'
                match=re.compile(regex,re.DOTALL).findall(x)[0]

                from jsunpack import unpack
                data=unpack(match)
                regex='sources.+?\[(.+?)\]'
                match=re.compile(regex,re.DOTALL).findall(data)[0]
               
                j_m=json.loads('['+match+']')
                
                
                for items in j_m:
                   
                    if 'file' in items:
                  
                        urls.append(items['file'])
                    
                        names_urls.append(original_title)
                    
                        resolvea.append(False)
              elif 'youtube' not in item and 'http' in item:
                  
                 regex_n='//(.+?)/'
                 match_n=re.compile(regex_n).findall(item)[0]
                 
                 name1,match_s,res,check=server_data(item,match_n)
                 if check:
                   names_urls.append(match_n)
                   resolvea.append(True)
                   urls.append(item)
        return names_urls,urls,x
            
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    global res2
    progress='Start'
    start_time=time.time()
    
    url='https://ganol.si/search/?q='+clean_name(original_title,1).replace(' ','+')
    all_links=[]
    headers = {
        #'Host': 'ganool.im',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        #'Referer': 'https://ganool.im/?s=black+panther',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    progress='requests'
    html=requests.get(url,headers=headers).content
  
    regex_pre='<div class="movies-list-wrap(.+?)<div class="clearfix"'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    regex='<a href="(.+?)".+?title="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(match_pre[0])
    
    count=0
    for link,name_in in match:
        
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
              break
        
        if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in name_in:
          
           
            

                          
            name1=name_in.replace('Ganool.ac','').replace('Ganool.AG','').strip()
            if "1080" in link:
                res="1080"
            elif "720" in link:
                res="720"
            elif "480" in link:
                res="720"
            elif "hd" in link.lower():
                res="HD"
            else:
                res=' '
            progress='Get-'+str(count)
          
            names,urls,x=get_ganol(link,original_title)
           
            for item in urls:
                progress='Links2-'+str(count)
                if stop_all==1:
                    break
                progress='Check-'+str(count)
                name2,match_s,res3,check=server_data(item,original_title)
                if check:
                    if 'gano' in match_s:
                            match_s='Direct'
                    if 'google' in match_s:
                            match_s='Google'
                    if res==' ':
                        res=res2
                    all_links.append((name1,item,match_s,res))
                    global_var=all_links
            progress='Regex-'+str(count)
            regex='<td style="font-weight:normal"><a href="(.+?)"'
            match2=re.compile(regex).findall(x)
         
            for link2 in match2:
                progress='links23-'+str(count)
                if stop_all==1:
                    break
                if 'upto' in link2 or 'clicknupload' in link2:
                    progress='Check3-'+str(count)
                    name2,match_s,res2,check=server_data(link2,original_title)
                    if check:
                        if 'gano' in match_s:
                            match_s='Direct'
                        all_links.append((name1,link2,match_s,res))
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var