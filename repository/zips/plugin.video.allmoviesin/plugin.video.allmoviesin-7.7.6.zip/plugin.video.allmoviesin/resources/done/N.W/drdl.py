# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains
type=['tv','rd']

import urllib2,urllib,logging,base64,json

color=all_colors[89]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    logging.warning('DRDL:'+episode+','+episode_n)
    base_link = 'https://directdownload.tv'
   
    search_link = base64.b64decode('L2FwaT9rZXk9NEIwQkI4NjJGMjRDOEEyOSZrZXl3b3JkPQ==')
    b_link = 'aHR0cDovL2lwdjYuaWNlZmlsbXMuaW5mbw=='
    u_link = 'aHR0cDovL2lwdjYuaWNlZmlsbXMuaW5mby9tZW1iZXJzb25seS9jb21wb25lbnRzL2NvbV9pY2VwbGF5ZXIvdmlkZW8ucGhwP2g9Mzc0Jnc9NjMxJnZpZD0lcyZpbWc9'
    r_link = 'aHR0cDovL2lwdjYuaWNlZmlsbXMuaW5mby9pcC5waHA/dj0lcyY='
    j_link = 'aHR0cDovL2lwdjYuaWNlZmlsbXMuaW5mby9tZW1iZXJzb25seS9jb21wb25lbnRzL2NvbV9pY2VwbGF5ZXIvdmlkZW8ucGhwQWpheFJlc3AucGhwP3M9JXMmdD0lcw=='
    p_link = 'aWQ9JXMmcz0lcyZpcXM9JnVybD0mbT0lcyZjYXA9KyZzZWM9JXMmdD0lcw=='
   
   
    links = []
    all_links=[]
    f = 'S%sE%s' % ((season_n), (episode_n))
    t = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', clean_name(original_title,1))
    t = t.replace("&", "")
    
    q = search_link + urllib.quote_plus('%s %s' % (t, f))
   
    q = urlparse.urljoin(base_link, q)
    print q
    result= requests.get(q).content
    print result
    result = json.loads(result)

    result = result['results']
    for i in result:
        if stop_all==1:
            break
        if clean_name(original_title,1).lower() in i['showName'].lower() :
            
            for lk in i['links']:
               if stop_all==1:
                    break
               for link in i['links'][lk]:
                if stop_all==1:
                    break
                host = link.replace("\\", "")
                host2 = host.strip('"')
                host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
              
                if host not in rd_domains:
                    continue

             
                if '.iso' in link or '.rar' in link or '.zip' in link:
                    continue
                names=link.split('/')
                name1=names[len(names)-1]
                if '1080' in name1:
                      res='1080'
                elif '720' in name1:
                      res='720'
                elif '480' in name1:
                      res='480'
                elif '360' in name1:
                      res='360'
                else:
                      res='720'
          
                name1,match_s,res,check=server_data(link,original_title,direct='rd')
                if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                    check1=True
                else:
                    check1=False
                    
                    
                      
                if check and check1:
                        logging.warning('DRDL:'+name1)
                        all_links.append((name1,link,host,res))
                        global_var=all_links
    return global_var
               