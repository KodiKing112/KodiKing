# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
from urlparse import urljoin
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,res_q
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[68]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
        search_url='https://putlockersnewsite2018.com/search?keyword='+clean_name(original_title,1).replace(' ','+')+'+season+%s'%(season)
    else:
        search_url='https://putlockersnewsite2018.com/search?keyword='+clean_name(original_title,1).replace(' ','+')
    progress='requests'
 
    x,token=cloudflare_request(search_url)

    #x=requests.get(search_url,headers=token[1],cookies=token[0]).content
  
    regex='div data-movie-id=".+?" class="ml-item"> <a href="(.+?)"'
    progress='Regex'
    m_pre=re.compile(regex,re.DOTALL).findall(x)
    count=0
    
    for items in m_pre:
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
            break
        check=False
        new_link=items
        if tv_movie=='tv':
            
            if 'season-%s-'%(season) in items and clean_name(original_title,1).lower().replace(' ','-') in items:
                check=True
                regex_ep='episode-(.+?)-'
                progress='Regex-'+str(count)
                r=re.compile(regex_ep,re.DOTALL).findall(items)[0]
                new_link=items.replace('episode-%s-'%r,'episode-%s-'%episode)
        else:
            if  clean_name(original_title,1).lower().replace(' ','-') in items and ('-'+show_original_year) in items:
                check=True
        if check:
            
            progress='Requests2-'+str(count)
            x2=requests.get(new_link,headers=base_header).content
      
            regex="var id = '(.+?)'.+?var e = '(.+?)'"
            progress='Regex3-'+str(count)
            m2=re.compile(regex,re.DOTALL).findall(x2)
            
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Referer': new_link,
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }
            

            data = {
              'id': m2[0][0],
              'e': m2[0][1],
             
            }
            progress='requests3-'+str(count)
            response = requests.post('https://putlockersnewsite2018.com/get-links/', headers=headers, data=data).json()
            print response
            for items_in in response :
                print 'itemsin'
                print items_in
                if stop_all==1:
                    break
                progress='check-'+str(count)
                name1,match_s,res,check=server_data(items_in['src'],original_title)
                        
                if check:
                      all_links.append((name1.replace("%20"," "),items_in['src'],match_s,res))

                      global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
 

    
   