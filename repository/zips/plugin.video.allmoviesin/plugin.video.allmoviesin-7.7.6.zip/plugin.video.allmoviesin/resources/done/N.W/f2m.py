# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[67]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    url='http://www.film2movie.us/search/'+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    html=client.request(url)
    regex='<h2><a href="(.+?)" rel="bookmark" title="(.+?)<'
    match=re.compile(regex).findall(html)
    for items,title in match:
        if stop_all==1:
             break
        x=client.request(items)
        regex='<a href="(.+?)" target="_blank" rel="noopener noreferrer"'
        match=re.compile(regex).findall(x)
        for link in match:
            if stop_all==1:
                    break
            if 'dubbed' not in link.lower() and 'film2movie' not in link and 'subf2m' not in link:
                    split_link=link.split('/')
                    name1=split_link[len(split_link)-1].replace('.mp4','').replace('.mkv','').replace('.avi','')
                    regex='//(.+?)/'
                    match_s=re.compile(regex).findall(link)[0]
                    if "1080" in link:
                      res="1080"
                    elif "720" in link:
                      res="720"
                    elif "480" in link:
                      res="720"
                    elif "hd" in link.lower():
                      res="HD"
                    else:
                     res=' '
                    all_links.append((name1,link,match_s,res))
                    global_var=all_links
    return global_var