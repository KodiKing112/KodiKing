# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[81]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        all_links=[]
        base_link = domain_s+'www.timetowatch.video'
              
        base,cook = cloudflare_request(base_link,headers=base_header)
        regex='<input type="hidden" name="(.+?)">'
        match2=re.compile(regex).findall(base)
        search_link = '/?s=%s'
        search_id = clean_name(original_title,1).lower()
        url = urlparse.urljoin(base_link, search_link)
        url = url  % (search_id.replace(':', '%3A').replace(',', '%2C').replace('&', '%26').replace("'", '%27').replace(' ', '+').replace('...', ' '))
     
        search_results,cook = cloudflare_request(url+'&'+match2[0]+'=',headers=base_header)
       
        match = re.compile('<div data-movie-id=.+?href="(.+?)".+?oldtitle="(.+?)"',re.DOTALL).findall(search_results)
    
        for movie_url, movie_title in match:
            if stop_all==1:
                    break
            clean_title = clean_name(original_title,1)
            movie_title = movie_title.replace('&#8230', ' ').replace('&#038', ' ').replace('&#8217', ' ').replace('...', ' ')
            
            if clean_title.lower() == movie_title.lower():
                html,cook = cloudflare_request(movie_url,headers=base_header)
                links = re.compile('id="linkplayer.+?onclick=.+?href="(.+?)"',re.DOTALL).findall(html)
             
                for link in links:
                    if stop_all==1:
                        break
                    if 'gomostream' not in link and 'akaplayer.com' not in link:
                        if 'videospider' in link:
                            headers = {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Referer': movie_url,
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                                'TE': 'Trailers',
                            }
                            parsed = urlparse.urlparse(link)
                            params = (
                                ('key', urlparse.parse_qs(parsed.query)['key']),
                                ('video_id', urlparse.parse_qs(parsed.query)['video_id']),
                            )
        
                            response = requests.get('https://videospider.in/getvideo', headers=headers, params=params)
                        
                            regex='<iframe src="(.+?)"'
                            match=re.compile(regex).findall(response.content)
                      
                            if len(match)==0:
                                f_url=response.url
                            else:
                               f_url=match[0]
                            name1,match_s,res,check=server_data(f_url,original_title)
                            
                            if check :
                                all_links.append((name1,f_url,match_s,res))
                                global_var=all_links
                        elif 'api.odb' in link:
                            response=requests.get(link).content
                            regex='<iframe.+?src="(.+?)"'
                            match=re.compile(regex).findall(response)
                            
                            name1,match_s,res,check=server_data(match[0],original_title)
                            
                            if check :
                                all_links.append((name1,match[0],match_s,res))
                                global_var=all_links
                            
                        else:
                            name1,match_s,res,check=server_data(link,original_title)
                            if check:
                              all_links.append((name1.replace("%20"," "),link,match_s,res))
                              global_var=all_links
        return all_links