# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
try:
    from general import Addon
except:
  import Addon
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json

color=all_colors[110]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year
      s_type='Movies'
    else:
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20s'+season_n+'e'+episode_n
      s_type='TV'
  
 
    
    all_links=[]
    
    if 1:
        
            
        x,cook=cloudflare_request('https://movcr.to',headers=base_header)
      
        x=requests.get('https://movcr.to/search/search.php?q='+(search_url),headers=cook[1],cookies=cook[0]).content
        print 'https://movcr.to/search/search.php?q='+(search_url)
        
        regex_pre='<tr>(.+?)</tr>'
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        
        for items in m_pre:
            
            regex='</i></a><a href="(.+?)">(.+?)<.+?"coll-2">(.+?) / (.+?)<.+?leeches">(.+?)<'
            macth_pre=re.compile(regex,re.DOTALL).findall(items)
            if stop_all==1:
                 break
        
                
                
            for link,title,seed,peer,size, in macth_pre:
                    if 'Dubbed' in title:
                        continue
                    info=(PTN.parse(title.replace(' ','.').replace('(','').replace(')','')))
                    check=False
                    check1=False
                    try:
                        ttile=info['title']
                        if ttile.lower()==clean_name(original_title,1).lower():
                            check=True
                    except:
                        ttile=clean_name(original_title,1).lower()
                        if clean_name(original_title,1).lower() in ttile.lower():
                            check=True
                    
                    try:
                        tyear=info['year']
                        if str(tyear)==show_original_year:
                            check1=True
                    except:
                        
                            check1=True
                    
                    if check and check1:
                         if stop_all==1:
                            break
                         if '4k' in title:
                              res='2160'
                         elif '2160' in title:
                              res='2160'
                         elif '1080' in title:
                              res='1080'
                         elif '720' in title:
                              res='720'
                         elif '480' in title:
                              res='480'
                         elif '360' in title:
                              res='360'
                         else:
                              res='HD'
                        
                         o_link=link
                       
                         try:
                             o_size=size
                             size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                             if 'MB' in o_size:
                               size=size/1000
                         except Exception as e:
                            print e
                            size=0
                         max_size=int(Addon.getSetting("size_limit"))
                        
                         if size<max_size:
                          
                           all_links.append((title,'https://movcr.to'+o_link,'- movc - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                       
                           global_var=all_links

    return global_var
        
    