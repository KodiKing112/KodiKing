# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[77]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]
   
    #headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    tk,cook=cache.get(cfscrape.get_content,3,domain_s+'watchhdmovie.net/',30,headers, table='cookies')
    
    html = requests.get(domain_s+'watchhdmovie.net/?s='+clean_name(original_title,1).replace(" ","+")+'+'+show_original_year,headers=headers,cookies=tk).content
    Links = re.compile('<a href="(.+?)" title="(.+?)"').findall(html)

    year=show_original_year
    
    for link,name in Links:
        if stop_all==1:
                    break
        link = link.replace('\\','')
  
        if clean_name(original_title,1).lower() in name.lower().replace(':',''): 
            if year in name:
                holder = requests.get(link,headers=headers,cookies=tk).content
                
                final_url = re.compile(domain_s+'watchhdmovie.net/r/\?(.+?)"').findall(holder)
                for links_in in final_url:
                    if stop_all==1:
                        break
                    resolvable=resolveurl.HostedMediaFile(links_in).valid_url()
                    if 'vidmoly.me' in links_in:
                      links_in=links_in.replace('w/','/embed-')+'.html'
                      xx=requests.get(links_in,headers=headers).content
                     
                      links_in=re.compile("<source src='(.+?)'").findall(xx)
                      if len(links_in)>0:
                          all_links.append((original_title,links_in[0],'vidmoly','1080'))
                          global_var=all_links
                    if resolvable:
                       
                        name1,match_s,res,check=server_data(links_in,original_title)
                        
                          
                        if check :
                            all_links.append((name1,links_in,match_s,'1080'))
                            global_var=all_links
                #sources.append({'source':host,'quality':'1080p','language': 'en','url':final_url,'info':[],'direct':False,'debridonly':False})
    return global_var
    