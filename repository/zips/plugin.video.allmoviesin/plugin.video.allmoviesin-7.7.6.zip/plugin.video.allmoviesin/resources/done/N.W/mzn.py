# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[3]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    
    search_title=clean_name(original_title,1).replace(' ','+')
    url='https://moviezen.co/?s='+search_title
    x=requests.get(url,headers=base_header).content
    regex='<a class="clip-link".+?href="(.+?)">.+?<h2 class="entry-title">.+?title="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(x)
    for link,title in m:
        if '(' in title:
            title=title.split('(')[0].strip().replace('Permalink to ','')

        if title.lower()!=clean_name(original_title,1).lower():
            continue
        
        y=x=requests.get(link,headers=base_header).content
        regex='https://href.li/\?(.+?)"'
        m2=re.compile(regex).findall(y)
        lk=[]
        for links in m2:
            if links=='https://www.pinoymovieshub.cc/':
                continue
            if links not in lk :
                lk.append(links)
                name2,match_s,res,check=server_data(links,original_title)
               
                if check:
                    if res==' ':
                        res='720'
                    all_links.append((name2,links,match_s,res))
                    
                    global_var=all_links
    return all_links
   