# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[15]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
   global global_var,stop_all

   all_links=[]
   url='https://www.couchtuner.click/watch-tv-shows/'
   headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    #'Host': 'couchtuner.unblocked.lol',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
   }
   html=requests.get(url,headers=headers).content
   regex='<li id="menu-item-.+?<a href="(.+?)">(.+?)<'
   match=re.compile(regex).findall(html)
   
   for link,name in match:
   
     if stop_all==1:
          break
     if clean_name(original_title,1).lower() in name.lower():
       print link
       yy=requests.get(link,headers=headers).content
       regex='span class="catDivTest">.+?<a href="(.+?)".+?Season %s Episode %s<'%(season,episode)
       print regex
       match2=re.compile(regex,re.DOTALL).findall(yy)
       print match2
       for links in match2:
         
         zz=requests.get(links,headers=headers).content
         regex='Watch it here :</span> <a href="(.+?)"'
         match3=re.compile(regex).findall(zz)
         
         for links_in in match3:
           if stop_all==1:
                    break
           time.sleep(0.3)
           headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                #'Host': 'mycouchtuner.nu',
                'Pragma': 'no-cache',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
           }
           vv=requests.get(links_in,headers=headers).content
           
           regex='<iframe src="(.+?)"'
           match4=re.compile(regex).findall(vv)
      
           for f_link in match4:
             
              if stop_all==1:
                    break
              if 'ecouchtuner' in f_link:
                try:
                 f_link=requests.get(f_link,headers=headers).url
                except:
                 continue
              name1,match_s,res,check=server_data(f_link,original_title)
              
              if check :
                all_links.append((name1,f_link,match_s,res))
                global_var=all_links
   return all_links
   