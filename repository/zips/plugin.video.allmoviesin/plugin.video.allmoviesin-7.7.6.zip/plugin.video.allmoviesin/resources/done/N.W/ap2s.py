# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global progress
progress=''
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[98]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    global progress
    progress='Start ap2s'
    start_time=time.time()
    all_links=[]
    x=requests.get('http://ap2s.net/search/?keyword='+clean_name(original_title,1).replace(' ','+')+'+season+'+season,headers=base_header).content
    
    progress='Regex'
    regex='<h3 class="video-title"><a href="(.+?)"'
    match=re.compile(regex).findall(x)
    count=0
    for link in match:
       
        progress=' Links - '+str(count)
        count+=1
        if stop_all==1:
            break
        y=requests.get(link,headers=base_header).content
        regex='<a class="play-video" href="(.+?)"'
        match2=re.compile(regex).findall(y)[0]
       
        z=requests.get(match2,headers=base_header).content
        regex='a class="page-numbers.+?" href="(.+?)" title=".+?">%s<'%episode
       
        match2=re.compile(regex).findall(z)[0]
    
        zz=requests.get(match2,headers=base_header).content
        regex='source src="(.+?)" label="(.+?)"'
        match3=re.compile(regex).findall(zz)
        
        for links,res in match3:
            if stop_all==1:
                break

            all_links.append((original_title,links,'Google',res))
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var