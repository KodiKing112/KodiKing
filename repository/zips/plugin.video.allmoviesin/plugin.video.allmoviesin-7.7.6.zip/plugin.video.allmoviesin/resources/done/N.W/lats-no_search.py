# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[36]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': domain_s+'letsupload.co/search.html',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('sEcho', '38'),
        ('iColumns', '1'),
        ('sColumns', ''),
        ('iDisplayStart', '0'),
        ('iDisplayLength', '50'),
        ('filterText', clean_name(original_title,1)),
        ('filterType', ''),
    )

    html = requests.get(domain_s+'letsupload.co/ajax/_search.ajax.php', headers=headers, params=params).json()

 
    for items in html['aaData']:
       if stop_all==1:
                    break
       regex='<h6>(.+?)</h6><a class="resultUrl" href="(.+?)"'
       match=re.compile(regex,re.DOTALL).findall(items[0])
       for name_in,link, in match:
          if stop_all==1:
                    break
          if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in name_in:
             if "HD" in name_in:
              res="HD"
             elif "720" in name_in:
              res="720"
             elif "1080" in name_in:
               res="1080"
             else:
               res=' '
             link_f=link
             '''
             regex='https://letsupload.co/(.+?)/'
             m=re.compile(regex).findall(link)[0]
             
             u='https://letsupload.co/plugins/mediaplayer/site/_embed.php?u=%s&w=1920&h=1080'%m
             ur2=requests.get(u, headers=headers).content
             regex='file: "(.+?)"'
             link_f=re.compile(regex).findall(ur2)[0]
             '''
             
             all_links.append((name_in.replace("%20"," "),link_f,'Letsupload',res))
             global_var=all_links
    return global_var
    