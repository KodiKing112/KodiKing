# -*- coding: utf-8 -*-
import requests,PTN,cache
import unjuice,time,Addon

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[26]
def get_movie_data():
    global stop_all
    headers={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; Le X820 Build/FEXCNFN5801809292S)',

    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'utf-8'}
    all_m={}
    all_dr=['NyAAXk2Dw','EyrYgZfFP','V17Yc7mtP','NkNB_7KFv','41aC6DQuP','N1LFtCcBP','Ny9oZQTfv','E1gsq_--D','Nkd2ydbkv','NkjgEO19w','4kupHAskw','4JpfLDM9w','N1WgFq-JD','E1PT6U2LD']
    for key in all_dr:
        if stop_all==1:
            break
        try:
            
            x=requests.get('http://next.json-generator.com/api/json/get/'+key,headers=headers).json()
            
            for items in x:
                if stop_all==1:
                    break
                all_m[items['title']]=items['urlvideo']
        except:
            
            pass
    return all_m
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    
    all_m=cache.get(get_movie_data,72, table='pages')
   
    
    for items in all_m:
        if stop_all==1:
            break
        if clean_name(original_title,1).lower() in str(items).lower():
              x=requests.get(all_m[items],headers=base_header).content
           
              if 'Not ready' in x:
                continue
              all_links.append((clean_name(original_title,1),all_m[items],'Direct','1080'))
              global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    