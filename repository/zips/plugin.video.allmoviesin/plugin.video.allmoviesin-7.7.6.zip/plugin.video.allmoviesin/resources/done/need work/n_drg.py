# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,logging
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,client,all_colors,res_q,base_header
type=['tv','movie','subs']

import urllib2,urllib,base64,json
color=all_colors[29]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    start_time=time.time()
    all_links=[]
    progress='Start'
    drivers_id=['0AJ9B3JMIEupUUk9PVA','0ADC-YBmY3OrdUk9PVA','08867656313741531868','13523321451877887276','18181068883723634962']
    tokens=['1%2Fe9U3IVn9Fu8FL6bI5po3jwJyGWWFZsB8VCxO6UhCbDY','1%2FT_ytmWeTvnXw1WWsJjlGeB6_WhmWykR3tzUaXS5Qhx8Z4rRMj0kHW6eD-MOW1mg1','1%2F9zu0zghVtghKtzIPbaeki85g6FX4LOdqUZsh7W5rsBM','1%2F1BKZ43Zj9bkaIC7aINqxSdlXPT2SFQxl-p_hYV2ZBMWCrDXMmVk2ceXKmMLMWMFG','1%2FMhSQF7Uw2gi7fX1TNSVDc_P8No6BgD7syePokTt_4OA']
    dr_data={}
    dr_data['drive1']={}
    dr_data['drive1']['name']='Drive1'
    dr_data['drive1']['drivers_id']='0AJ9B3JMIEupUUk9PVA'
    dr_data['drive1']['token']='1%2Fe9U3IVn9Fu8FL6bI5po3jwJyGWWFZsB8VCxO6UhCbDY'

    dr_data['drive2']={}
    dr_data['drive2']['name']='Drive2'
    dr_data['drive2']['drivers_id']='0ADC-YBmY3OrdUk9PVA'
    dr_data['drive2']['token']='1%2FT_ytmWeTvnXw1WWsJjlGeB6_WhmWykR3tzUaXS5Qhx8Z4rRMj0kHW6eD-MOW1mg1'
    for items in dr_data:
 

        drive_id=dr_data[items]['drivers_id']
        search_name=original_title
        headers = {
            'Connection': 'Keep-Alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0; Redmi Note 4X MIUI/V10.2.1.0.MBFMIXM)'
        }
        progress='requests Herok'
        url='https://drive-login.herokuapp.com/refresh'
        body='refresh_token=%s&provider=googledrive'%dr_data[items]['token']
        headers={'addon': 'plugin.noone 1.0.2/1.0.2'}
        x=requests.post(url,headers=headers,params=body).json()


        url="https://www.googleapis.com/drive/v3/files?q=fullText contains '%s'&spaces=drive&includeTeamDriveItems=true&prettyPrint=false&fields=files(id,name,modifiedTime,size,mimeType,description,hasThumbnail,thumbnailLink,owners(permissionId),parents,trashed,imageMediaMetadata(width),videoMediaMetadata)&teamDriveId=%s&corpora=teamDrive&supportsTeamDrives=true"%(search_name,drive_id)
        headers= {'authorization': u'Bearer %s'%x['access_token']}
        progress='requests key'
        y=requests.get(url,headers=headers).json()

        for items2 in y['files']:
            if stop_all==1:
                break
            progress=items2
            name1=items2['name']
           
            if tv_movie=='tv':
                regex='s%se%s[^0-9]'%(season_n,episode_n)
                m=re.compile(regex).findall(name1.lower())
                regex='s%se%s[^0-9]'%(season,episode)
                m2=re.compile(regex).findall(name1.lower())
                if len(m2)==0 and len(m)==0 :
                    continue
            id=items2['id']
            url='https://www.googleapis.com/drive/v3/files/%s?access_token=y%s&alt=media'%(id,x['access_token'])
            if 'video' in items2['mimeType']:
                progress='getting'
                z=requests.get(url,headers=headers,stream=True).url
                res=res_q(name1)
                try_head = requests.head(z,headers=base_header, stream=True,verify=False,timeout=15)
                if 'Content-Length' in try_head.headers:
          
                    if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Google'+' - '+f_size2
                    else:
                        s_name='Google'
                all_links.append((name1,z,s_name,res))                
                    
                global_var=all_links
                
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var