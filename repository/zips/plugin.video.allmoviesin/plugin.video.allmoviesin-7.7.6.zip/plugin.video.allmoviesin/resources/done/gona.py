# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[30]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    if 'Agents Of S.h.i.e.l.d'.lower() in clean_name(original_title,1).lower():
         original_title='Agents%20Of%20S.h.i.e.l.d.'
                         
    all_links=[]
    if tv_movie=='tv':
      url='http://gonnawatch.com/search-movies/%s.html'%(original_title+'%20season%20'+season)
    else:
      url='http://gonnawatch.com/search-movies/%s.html'%original_title
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    #'Host': 'gonnawatch.com',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    progress='requests'
    
    html=requests.get(url,headers=headers).content
    
    if tv_movie=='tv':
        regex='<div class="titl(.+?)"><a href="(.+?)">(.+?): Season'
    else:
      regex='year">(.+?)<.+?div class="title"><a href="(.+?)">(.+?)<'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
    
    count=0
    for year,link,title in match:
       print link
       progress='Links-'+str(count)
       count+=1
       if stop_all==1:
           break
       if tv_movie=='tv':
         year=show_original_year
       if stop_all==1:
         break
       if title.lower()==clean_name(original_title,1).lower() and year==show_original_year:
         print 'l'
         x=requests.get(link,headers=headers).content
         if tv_movie=='tv':
           regex='a class="episode episode_series_link" href="(.+?)">(.+?)</a>'
           
       
           match6=re.compile(regex).findall(x)

           for link,episode_in in match6:
             if episode_in==episode:
               progress='requests2-'+str(count)
               x=requests.get(link,headers=headers).content
         regex='class="server_play"><a href="(.+?)"'

         match4=re.compile(regex).findall(x)
   
         for links2 in match4:
          print links2
          progress='Links2-'+str(count)
          if stop_all==1:
                break
          progress='requests3-'+str(count)

          x=requests.get(links2,headers=headers).content
          regex='Base64.decode\("(.+?)"'
          match2=re.compile(regex).findall(x)
          if len(match2)>0:
            link1=match2[0].decode('base64')
            print link1
            regex='src="(.+?)"'
            match3=re.compile(regex).findall(link1)
            
            try:
                
          
                if 'eplayvid' in match3[0]:
                    y=requests.get(match3[0],headers=headers).content
                    regex='source src="(.+?)"'
                    f_link=re.compile(regex).findall(y)
                    
                    
                    names=f_link[0].split('/')
     
                    name1=names[len(names)-1]
                    if "1080" in name1:
                        res="1080"
                    elif "720" in name1:
                        res="720"
                    elif "480" in name1:
                        res="720"
                    elif "hd" in name1.lower():
                        res="HD"
                    else:
                       res=' '
                    headers2 = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Host': 'entervideo.net',
                    'Pragma': 'no-cache',
                    'Referer':match3[0],
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                    }
                    head=urllib.urlencode(headers2)
                    try_head = requests.get(f_link[0],headers=headers2, stream=True,verify=False,timeout=10)
                    f_size2='0.0 GB'
       
                    if 'Content-Length' in try_head.headers:
                       if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Direct'+' - '+f_size2
                    else:
                        s_name='Direct'
                    all_links.append((name1,f_link[0]+"|"+head,s_name,res))
                    global_var=all_links
                    break
                #else:
                  
                     
                #        name1,match_s,res,check=server_data(match3[0],original_title)
                #        if check :
                #          all_links.append((name1,match3[0],match_s,res))
                #          global_var=all_links
            except:
             pass

          
          #regex='<a title="Click here to Play on .+?" href="(.+?)"'
          #match5=re.compile(regex).findall(x)

          #if len(match5)>0:
          #      name1,match_s,res,check=server_data(match5[0],original_title)
          #      if check:
          #        all_links.append((name1,match5[0],match_s,res))
          #        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var