# -*- coding: utf-8 -*-
import requests,PTN,urlparse
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[20]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    
    
    
    all_links=[]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://drive.himanshurahi.workers.dev',
        'Connection': 'keep-alive',
        #'Referer': 'https://drive.himanshurahi.workers.dev/uploadbot/',
        'TE': 'Trailers',
    }

    data = '{password:null}'
   
    response = requests.post('https://drive.himanshurahi.workers.dev/uploadbot/', headers=headers, data=data).json()
    
    
    all_ep=[' s%se%s '%(season_n,episode_n),'.s%se%s.'%(season_n,episode_n),' s%s e%s '%(season_n,episode_n),'.s%s.e%s.'%(season_n,episode_n),'.s%s e%s.'%(season_n,episode_n)]
    search_term=original_title
    for items in response['files']:
       
     if search_term.lower().replace('%20',' ').replace(' ','.') in items['name'].lower().replace(' ','.'):
        
        if 'folder' in items['mimeType']:
            headers['Referer']='https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/'
            
            
            r = requests.post('https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/', headers=headers, data=data).json()
            
            
            for items2 in r['files']:
                if 'video' in items2['mimeType']:
                    ok=False
                    if tv_movie=='tv':
                    
                     for it in all_ep:
                        if it.lower() in items2['name'].lower():
                            ok=True
                            break
                    else:
                        if show_original_year in items2['name']:
                            ok=True
                    if ok:
                        print items2['name']
                        
                        size=str(round(float(items2['size'])/(1024*1024*1024), 2))+' GB'
                        res=res_q(items2['name'])
                        link='https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/'+items2['name'].replace(' ','%20')
                        all_links.append((items2['name'],link,'Direct - '+size,res))
                        global_var=all_links
                if 'folder' in items2['mimeType']:
                    
                    headers['Referer']='https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/'+items2['name'].replace(' ','%20')+'/'
                    
                    r2 = requests.post('https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/'+items2['name'].replace(' ','%20')+'/', headers=headers, data=data).json()
                    
                    for items3 in r2['files']:
                        if 'video' in  items3['mimeType']:
                            ok=False
                            if tv_movie=='tv':
                             
                             for it in all_ep:
                                if it.lower()  in items3['name'].lower():
                                    ok=True
                                    break
                            else:
                                if show_original_year in items3['name']:
                                    ok=True
                            if ok:
                                print items3['name']
                                
                        
                                size=str(round(float(items3['size'])/(1024*1024*1024), 2))+' GB'
                                res=res_q(items3['name'])
                                link='https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')+'/'+items2['name'].replace(' ','%20')+'/'+items3['name'].replace(' ','%20')
                                all_links.append((items3['name'],link,'Direct - '+size,res))
                                global_var=all_links
            if 'video'  in items['mimeType']:
                ok=False
                if tv_movie=='tv':
                    
                     for it in all_ep:
                        if it.lower()  in items['name'].lower():
                            ok=True
                            break
                else:
                    if show_original_year in items['name']:
                        ok=True
                if ok:
                    print items['name']
                    size=str(round(float(items['size'])/(1024*1024*1024), 2))+' GB'
                    res=res_q(items['name'])
                    link='https://drive.himanshurahi.workers.dev/uploadbot/'+items['name'].replace(' ','%20')
                    all_links.append((items['name'],link,'Direct - '+size,res))
                    global_var=all_links
    return global_var