# -*- coding: utf-8 -*-
import requests,re,PTN,os
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
try:
    from general import Addon
except:
  import Addon
type=['movie','tv','torrent','subs']

import urllib2,urllib,logging,base64,json

color=all_colors[90]
dir_path = os.path.dirname(os.path.realpath(__file__))
mypath=dir_path

user_dataDir=os.path.join(mypath,'cache_f','hebits')


    
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    
    
    if not os.path.exists(user_dataDir):
        os.makedirs(user_dataDir)
    all_links=[]
    username = Addon.getSetting('username_hebits')
    password = Addon.getSetting('Password_sdr_hebits')
    if username=='' or password=='':
        return []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }

    data = {
      'username': username,
      'password': password
    }

    tk_cook = requests.post('https://hebits.net/takeloginAjax.php', headers=headers, data=data).cookies
    
    if tv_movie=='movie':
        search_str=clean_name(original_title,1).lower()+' '+show_original_year
    else:
        search_str1=clean_name(original_title,1).lower()+' '+show_original_year+' s'+season_n+'e'+episode_n
        search_str=clean_name(original_title,1).lower()+' s'+season_n+'e'+episode_n
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': '*/*',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Accept-Encoding': 'utf-8',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('q', search_str),
        ('bla', '1545550512864'),
    )

    response = requests.get('https://hebits.net/suggest.php', headers=headers, params=params, cookies=tk_cook).content
    if len(response)<10 and tv_movie=='tv':
        params = (
        ('q', search_str1),
        ('bla', '1545550512864'),
        )

        response = requests.get('https://hebits.net/suggest.php', headers=headers, params=params, cookies=tk_cook).content
    regex='<a href="(.+?)">(.+?)<'
    match=re.compile(regex).findall(response)
    index=0
    for link,name in match:

        
        
        if Addon.getSetting('rdsource')=='true':
            x=requests.get(link,headers=headers,cookies=tk_cook).content
            regex="title='title'><a href='(.+?)'"
            link='https://hebits.net/'+re.compile(regex).findall(x)[0]
            
            local_filename=os.path.join(user_dataDir,str(index)+'.torrent')
            f = open(local_filename, 'wb')
            r=requests.get(link,headers=headers,cookies=tk_cook)
            for chunk in r.iter_content(chunk_size=8096): 
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)

            
            f.close()
            index+=1
            link=local_filename
       
       
        if '1080' in name:
              res='1080'
        elif '720' in name:
              res='720'
        elif '480' in name:
              res='480'
        elif '360' in name:
              res='360'
        else:
              res='HD'
        if '/' in name:
            name=name.split('/')[1].strip()
        
        all_links.append((name,link,'- Hebits - '+str(0)+' GB'+' {P-%s/S-%s}'%('99','99'),res))
                   
        global_var=all_links
    return global_var

