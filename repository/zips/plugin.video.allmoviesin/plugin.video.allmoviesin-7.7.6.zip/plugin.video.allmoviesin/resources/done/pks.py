# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[106]

def get_f_link(link):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': link,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get('https://vidsrc.me/yeye', headers=headers).content
    return 'https://openload.co/embed/%s/'%response

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'https://www2.putlockerr.is'
    search_link = '/embed/%s/'
    progress='requests'
    if tv_movie=='movie':
      
      imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
      
      x=requests.get(imdbid_data).json()
      imdbid=x['imdb_id']
     
    else:
       imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
      
       x=requests.get(imdbid_data).json()
       imdbid=x['external_ids']['imdb_id']
         
    url =base_link + search_link % imdbid

    if tv_movie=='tv':
        url=url+'/%s-%s/'%(season,episode)
    r = client.request(url)
    progress='Regex'
    match = re.compile('<iframe src="(.+?)"').findall(r)
    count=0
    for link in match:
        progress='Links-'+str(count)
        count+=1
        if 'http' not in link:
            link='http:'+link
        
        o_link=get_f_link(link)

        
        if stop_all==1:
                    break
        progress='Check-'+str(count)
        name1,match_s,res,check=server_data(o_link,original_title)
                        
      
        if check :
            all_links.append((name1,o_link,match_s,res))
            global_var=all_links
        if 1:
     
            
            
            
            regex='vidsrc.me/embed/(.+?)/'
            
            imdb_in=re.compile(regex).findall(link)[0]
            if tv_movie=='tv':
                lk='https://vidsrc.me/watching?i=%s&s=%s&e=%s&srv=1'%(imdb_in,season,episode)
                rf_link='https://vidsrc.me/server1/%s/%s-%s/'%(imdb_in,season,episode)
            else:
                lk='https://vidsrc.me/watching?i=%s&srv=1'%imdb_in
                rf_link='https://vidsrc.me/server1/%s/'%imdb_in
                
                
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': rf_link,
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            n_irl=requests.get(lk,headers=headers).url
            
            regex='https://www.vidsource.me/v/(.+?)(?:/|$)'
            in_id_pre=re.compile(regex).findall(n_irl)
            
            if len(in_id_pre)>0:
            
                in_id=in_id_pre[0]
                headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': n_irl,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                }

                data = {
                  'r': rf_link,
                  'd': 'www.vidsource.me'
                }

                response = requests.post('https://www.vidsource.me/api/source/'+in_id, headers=headers, data=data).json()
                for items in response['data']:
                    res=items['label']
                    res1=res.replace('p','')
                    #name1,match_s,res,check=server_data(items['file'],name)
                        
                    if 1:#check:
                        all_links.append((name1.replace("%20"," "),items['file'],'Direct',res1))
                        global_var=all_links
            
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var