# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[105]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'https://watch4hd.com'
    search = '/series/?s='
    search_id=clean_name(original_title,1)
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))
    progress='requests'
    html=requests.get(start_url,headers=base_header).content
    if tv_movie=='movie':
        Regex = re.compile('class="movies-list-wrap mlw-category">.+?href=(.+?) .+?oldtitle="(.+?)" title>.+?rel=tag>(.+?)<',re.DOTALL).findall(html)
    else:
        Regex = re.compile('class=ml-item.+?href=(.+?) .+?qtip-title>(.+?)<.+? rel=tag>(.+?)<',re.DOTALL).findall(html)
    count=0
    for item_url,name,release in Regex:
        progress='Links-'+str(count)
        count+=1
        if search_id.lower() in name.lower() and show_original_year in release:
            
            progress='requests-'+str(count)
            OPEN = requests.get(item_url,headers=base_header).content
            if tv_movie=='tv':
                progress='Regex3-'+str(count)
                Regex3 = re.compile('><a.+?href=(.+?)>',re.DOTALL).findall(OPEN)
                
                for seasepisitem_url in Regex3:
             
                    epis=seasepisitem_url.split('episode-')[-1].split('/')[0].replace('00','').replace('01','1').replace('02','2').replace('03','3').replace('04','4').replace('05','5').replace('06','6').replace('07','7').replace('08','8').replace('09','9').replace(':','')

                    seas=seasepisitem_url.split('season-')[-1].split('-')[0].replace('00','').replace('01','1').replace('02','2').replace('03','3').replace('04','4').replace('05','5').replace('06','6').replace('07','7').replace('08','8').replace('09','9').replace(':','')

                    item_url=seasepisitem_url
                    if season==seas and episode==epis:
                       progress='requests-'+str(count)
                       OPEN = requests.get(item_url,headers=base_header).content
                       break
            
            o_res=' '
            if tv_movie=='movie':
                quality = re.compile('class=quality>(.+?)</span>',re.DOTALL).findall(OPEN)[0]
                if "1080" in quality:
                  o_res="1080"
                elif "720" in quality:
                  o_res="720"
                elif "480" in quality:
                   o_res="480"
                else:
                   o_res=' '
            
            Regex2 = re.compile('<iframe src.+?"(.+?)"').findall(OPEN)
            if len(Regex2)>0:
                for link in Regex2:
                    link=link.replace('\\','')
                    progress='Check-'+str(count)
                    name2,match_s,res,check=server_data(link,original_title)
                    if res==' ':
                      res=o_res
                    
                    if check:

                        all_links.append((name2,link,match_s,res))
                        
                        global_var=all_links
            else:
                Regex2 = re.compile('data-pmid=(.+?)<').findall(OPEN)
                for pmid in Regex2:
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': item_url,
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'X-Requested-With': 'XMLHttpRequest',
                        'Connection': 'keep-alive',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }

                    data = {
                      'pmid': pmid,
                      'action': 'c_get_m_e_l'
                    }
                    progress='requests2-'+str(count)
                    response = requests.post('https://watch4hd.com/wp-admin/admin-ajax.php', headers=headers, data=data).json()
                    link=response['data']
                    
                    link=link.replace('\\','')
                    progress='Check-'+str(count)
                    name2,match_s,res,check=server_data(link,original_title)
                    if res==' ':
                      res=o_res
                    
                    if check:

                        all_links.append((name2,link,match_s,res))
                        
                        global_var=all_links
                        
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links