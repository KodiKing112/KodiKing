# -*- coding: utf-8 -*-
#taken from CARTOON HD movies
import requests,PTN

import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q,base_header
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[62]


def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    all_links=[]
    x=requests.get('https://o2tvseries.co/search/?q='+clean_name(original_title,1).replace(' ','+'),headers=base_header).content
    regex='<li>.+?<a href="(.+?)".+?<h3>(.+?)<'
    m=re.compile(regex,re.DOTALL).findall(x)
    for lk,nm in m:
        if nm.lower()!=clean_name(original_title,1).lower():
            continue
        y=requests.get('https://o2tvseries.co'+lk,headers=base_header).content
        regex='<li>.+?<a href="(.+?)".+?<h3>(.+?)<'
        m2=re.compile(regex,re.DOTALL).findall(y)
       
        for lk2,nm2 in m2:
            if nm2!='Season '+season_n:
                continue
            print 'in'
            z=requests.get('https://o2tvseries.co'+lk2,headers=base_header).content
            regex='<li>.+?<a href="(.+?)".+?<h3>(.+?)<'
            m3=re.compile(regex,re.DOTALL).findall(z)
            regex='\?page=(.+?)"'
            pages=re.compile(regex).findall(z)
            break_page=False
            for page in pages:
                if break_page:
                    break
                z=requests.get('https://o2tvseries.co'+lk2+'?page='+page,headers=base_header).content
                regex='<li>.+?<a href="(.+?)".+?<h3>(.+?)<'
                m3=re.compile(regex,re.DOTALL).findall(z)
                for lk3,nm3 in m3:
                    
                    if 'S%sE%s'%(season_n,episode_n) not in nm3 and 'Episode '+episode_n not in nm3:
                      continue
                    break_page=True
                    break
                
                
            if break_page:
                
                a=requests.get('https://o2tvseries.co'+lk3,headers=base_header).content

                regex='<a id="download" href="(.+?)"'
                m4=re.compile(regex,re.DOTALL).findall(a)
                lk4='https://o2tvseries.co'+m4[0]
                
                
                headers = {
                    'authority': 'o2tvseries.co',
                    'cache-control': 'max-age=0',
                    'origin': 'https://o2tvseries.co',
                    'upgrade-insecure-requests': '1',
                    'content-type': 'application/x-www-form-urlencoded',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36',
                    'sec-fetch-dest': 'document',
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'sec-fetch-site': 'same-origin',
                    'sec-fetch-mode': 'navigate',
                    'sec-fetch-user': '?1',
                    'referer': lk4,
                    'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
                    }

                params = (
                    ('id', '45645'),
                )

                data = {
                  'd': '1',
                  'download': 'Continue Download'
                }

                try_head = requests.post(lk4, headers=headers, data=data,stream=True)
                link_in= try_head.url
                f_size2='0.0 GB'
                s_name='Direct'
                if 'Content-Length' in try_head.headers:
          
                    if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Direct'+' - '+f_size2
                    else:
                        s_name='Direct'
                    
        all_links.append((original_title.replace("%20"," "),link_in,s_name,'720'))
        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
                    
        
           