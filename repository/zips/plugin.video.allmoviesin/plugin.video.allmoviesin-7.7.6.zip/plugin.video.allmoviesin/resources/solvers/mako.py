import xbmcaddon,requests,json,urllib,cookielib,urlparse,urllib2,re,uuid
Addon = xbmcaddon.Addon()
username = Addon.getSetting("makoUsername")
password = Addon.getSetting("makoPassword")
deviceID = Addon.getSetting("makoDeviceID")
if deviceID.strip() == '':
    uuidStr = str(uuid.uuid1()).upper()
    deviceID = "W{0}{1}".format(uuidStr[:8], uuidStr[9:])
    Addon.setSetting("makoDeviceID", deviceID)
    
baseUrl = 'http://www.mako.co.il'
entitlementsServices = 'http://mass.mako.co.il/ClicksStatistics/entitlementsServicesV2.jsp'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'
endings = 'type=service&device=desktop&strto=true'
quality='best'
userAgent=UA
def OpenURL(url, headers={}, user_data=None, CookieJar=None, retries=1):
	link = ""
	handlers = [
		urllib2.HTTPHandler(),
		urllib2.HTTPSHandler(),
		urllib2.HTTPCookieProcessor(CookieJar)
	]
	opener = urllib2.build_opener(*handlers)
	req = urllib2.Request(url)
	req.add_header('Accept-encoding', 'gzip')
	for k, v in headers.items():
		req.add_header(k, v)
	if req.headers.get('User-Agent', '') == '':
		req.add_header('User-Agent', userAgent)
	for i in range(retries):
		try:
			response = opener.open(req, user_data, timeout=100)
			if response.info().get('Content-Encoding') == 'gzip':
				buf = StringIO( response.read())
				f = gzip.GzipFile(fileobj=buf)
				link = f.read()
			else:
				link = response.read()
			response.close()
			break
		except Exception as ex:
			xbmc.log(str(ex), 3)
			return None
	return link
def GetStreams(url, headers={}, user_data=None, CookieJar=None, retries=1, quality='best'):
	if quality.startswith('set'):
		addonKey = quality[4:]
		quality = 'set'
	base = urlparse.urlparse(url)
	baseUrl = '{0}://{1}{2}'.format(base.scheme, base.netloc, base.path)
	text = OpenURL(url, headers=headers, user_data=user_data, CookieJar=CookieJar, retries=retries)
	if text is None:
		return url
	resolutions = [x for x in re.compile('^#EXT-X-STREAM-INF:.*?BANDWIDTH=(\d+)(.*?)\n(.*?)$', re.M).findall(text)]
	resolutions = sorted(resolutions,key=lambda resolutions: int(resolutions[0]), reverse=True)
	link = url
	if quality == 'best':
		link = resolutions[0][2]
	elif quality == 'choose' or quality == 'set':
		if quality == 'set':
			resolutions.insert(0, (GetLocaleString(30024), '', ''))
		resNames = []
		for item in resolutions:
			resNames.append(item[0]) 
			if 'RESOLUTION' in item[1]:
				resNames[-1] += '  [{0}]'.format(re.compile('RESOLUTION=(\d+)x(\d+)').findall(item[1])[0][1])
			elif 'NAME' in item[1]:
				resNames[-1] += '  [{0}]'.format(re.compile('NAME="(.*?)"').findall(item[1])[0])
		qualityInd = xbmcgui.Dialog().select(GetLocaleString(30005), resNames)
		if qualityInd > -1:
			if quality == 'set':
				Addon.setSetting(addonKey, '' if qualityInd == 0 else resolutions[qualityInd][0])
			link = resolutions[qualityInd][2]
	else:
		quality = int(quality)
		res = 0
		for resolution in resolutions:
			_res = int(resolution[0])
			if _res >=  res and _res <=  quality:
				res = _res
				link = resolution[2]
	if not link.startswith('http'): 
		link = urlparse.urljoin(baseUrl, link)
	return link
def GetJson(url):
    html = requests.get(url, headers={"User-Agent": 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'}).content
    if html == "":
        return None
    resultJSON = json.loads(html)
    if resultJSON is None or len(resultJSON) < 1:
        return None
    if resultJSON.has_key("root"):
        return resultJSON["root"]
    else:
        return resultJSON
def Login():
	headers={"User-Agent": UA}
	text = OpenURL('{0}?eu={1}&da=6gkr2ks9-4610-392g-f4s8-d743gg4623k2&dwp={2}&et=ln&du={3}'.format(entitlementsServices, username, password, deviceID), headers=headers)
	result = json.loads(text)
	if result['caseId'] != '1':
		return result
	text = OpenURL('{0}?da=6gkr2ks9-4610-392g-f4s8-d743gg4623k2&et=gds&du={1}'.format(entitlementsServices, deviceID), headers=headers)
	return json.loads(text)
def GetTicket(link, headers):
    text = requests.get(link, headers=headers).content
    
    result = json.loads(text)
    if result['caseId'] == '4':
        result = Login()
        text = requests.get(link, headers=headers).content
        result = json.loads(text)
        if result['caseId'] != '1':
            xbmc.executebuiltin("XBMC.Notification({0}, You need to pay if you want to watch this video., {1}, {2})".format(AddonName, 5000 ,icon))
            return
    elif result['caseId'] != '1':
        xbmc.executebuiltin("XBMC.Notification({0}, Cannot get access for this video., {1}, {2})".format(AddonName, 5000 ,icon))
        return
    return urllib.unquote_plus(result['tickets'][0]['ticket'])
def GetLink(media, cdn, dv, headers, quality):
    url = ''
    for item in media:
        if item['format'] == '{0}_HLS'.format(cdn.upper()):
            url = item['url']
            break
    if url == '':
        return None, None
    if username.strip() == '':
        l = '{0}?et=gt&lp={1}&rv={2}'.format(entitlementsServices, url, cdn)
    else:
        l = '{0}?et=gt&na=2.0&da=6gkr2ks9-4610-392g-f4s8-d743gg4623k2&du={1}&dv={2}&rv={3}&lp={4}'.format(entitlementsServices, deviceID, dv, cdn, url)
    ticket = GetTicket(l, headers)
    if url.startswith('//'):
        url = 'http:{0}'.format(url) 
    cookie_jar = cookielib.LWPCookieJar()
    link = GetStreams('{0}&{1}'.format(url, ticket) if '?' in url else '{0}?{1}'.format(url, ticket), headers=headers, CookieJar=cookie_jar, quality=quality)
    return link, cookie_jar
def get_mako(url):
    url = "{0}&{1}".format(url, endings) if "?" in url else "{0}?{1}".format(url, endings)
    prms = GetJson(url)
    
   
    videoChannelId=prms["channelId"]
    vcmid = prms["video"]["guid"]
    url = "vcmid={0}&videoChannelId={1}".format(vcmid,videoChannelId)
    headers={"User-Agent": UA}
    dv = url[url.find('vcmid=')+6: url.find('&videoChannelId=')]
    ch = url[url.find('&videoChannelId=')+16:]
    text = requests.get('{0}/AjaxPage?jspName=playlist.jsp&vcmid={1}&videoChannelId={2}&galleryChannelId={1}&isGallery=false&consumer=web_html5&encryption=no'.format(baseUrl, dv, ch), headers=headers).content
    media = json.loads(text)['media']
    link, cookie_jar = GetLink(media, 'AKAMAI', dv, headers, quality)
    if link is None:
        link, cookie_jar = GetLink(media, 'CASTTIME', dv, headers, quality)
        if link is None:
            return None
    cookies = ";".join(['{0}'.format(urllib.quote('{0}={1}'.format(_cookie.name, _cookie.value))) for _cookie in cookie_jar])
    final = '{0}|User-Agent={1}&Cookie={2}'.format(link, UA, cookies)
    return final