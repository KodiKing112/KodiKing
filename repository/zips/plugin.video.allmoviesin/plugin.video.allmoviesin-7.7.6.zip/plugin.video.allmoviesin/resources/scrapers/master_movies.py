# -*- coding: utf-8 -*-
import cache
global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6
import  threading,xbmcplugin,sys,os,re,requests,logging,json,xbmcaddon
dir_path = os.path.dirname(os.path.realpath(__file__))

mypath=os.path.join(dir_path,'..\done')
sys.path.append(mypath)
Addon = xbmcaddon.Addon()
from general import replaceHTMLCodes
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
    
from addall import addLink,addDir3
import xbmc
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
user_dataDir_pre = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
from pen_addons import download_file,unzip,gdecom

if KODI_VERSION>=17:
 
  domain_s='https://'
elif KODI_VERSION<17:
  domain_s='http://'
all_dub=[]
all_dub2=[]
all_dub3=[]
all_dub4=[]
all_dub5=[]
all_dub6=[]

all_dub8=[]
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
user_dataDir=os.path.join(user_dataDir_pre,'cache_f','ghost')

if not os.path.exists(user_dataDir):
    os.makedirs(user_dataDir)
user_dataDir2=os.path.join(user_dataDir_pre,'cache_f','avegner')

if not os.path.exists(user_dataDir2):
    os.makedirs(user_dataDir2)
user_dataDir3=os.path.join(user_dataDir_pre,'cache_f','ornm')


if not os.path.exists(user_dataDir3):
    os.makedirs(user_dataDir3)
    
user_dataDir4=os.path.join(user_dataDir_pre,'cache_f','dragon')


if not os.path.exists(user_dataDir4):
    os.makedirs(user_dataDir4)
    
user_dataDir5=os.path.join(user_dataDir_pre,'cache_f','mosh')


if not os.path.exists(user_dataDir5):
    os.makedirs(user_dataDir5)

user_dataDir6=os.path.join(user_dataDir_pre,'cache_f','killer')


if not os.path.exists(user_dataDir6):
    os.makedirs(user_dataDir6)

user_dataDir7=os.path.join(user_dataDir_pre,'cache_f','hpm')


if not os.path.exists(user_dataDir7):
    os.makedirs(user_dataDir7)
    
master_string="SELECT * FROM MyTable where data not like '%tvshowtitle%'  and type='item' and name not like '%פרק%' and father not like '%מדובב%' and year not like '%9999%' and link not like '%ActivateWindow%' order by date DESC"

master_string_dragon="SELECT * FROM MyTable where  link not like '%ActivateWindow%' and data not like '%tvshowtitle%'  and type='item' and name not like '%פרק%' and father like '%סרטים%' and father not like '%מדובב%' and year not like '%9999%'  order by date DESC"

amount_per_master=300
def renew_data(path,l_list):


    download_file(l_list,path)

    unzip(os.path.join(path, "fixed_list.txt"),path)

    return 'ok'
def fix_date(stt):
    
    stt_new=stt.split('-')
    
    stt_new_1=stt_new[2].split(' ')
    
    if len(stt_new_1[0])<2:
        
        stt_new_2='0'+stt_new_1[0]
        
        stt=stt.replace('-'+stt_new_1[0]+' ','-'+stt_new_2+' ')
    
    return stt
def fix_data(data):
    return data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace("\n"," ").replace("\r"," ").replace("\t"," ")
def get_dub_movies():
    global all_dub
    l_list='https://github.com/oren2706/Multimedialist/blob/master/my%20movies%20list%20(ver1).txt?raw=true'
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir3,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir3)

        unzip(os.path.join(user_dataDir3, "fixed_list.txt"),user_dataDir3)
        

    else:

        all_img=cache.get(renew_data,1,user_dataDir3,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string)
    match = dbcur.fetchall()
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
        #logging.warning(name)
        all_dub.append((name,f_link,5,'[[ON]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1
def get_dub_movies2():
    global all_dub2
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    #l_list='https://files.fm/pa/moshep1977/upload/1.txt'
    l_list=Addon.getSetting("ghaddr").decode('base64')
    
    cacheFile=os.path.join(user_dataDir,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir)

        unzip(os.path.join(user_dataDir, "fixed_list.txt"),user_dataDir)

    else:

        all_img=cache.get(renew_data,1,user_dataDir,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string)
    match = dbcur.fetchall()
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub2.append((name,f_link,5,'[[GH]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1
def get_dub_movies3():
    global all_dub3
    import cache
    l_list='https://raw.githubusercontent.com/kodimen/Steve-Rogers/master/%D7%94%D7%A0%D7%95%D7%A7%D7%9D%20%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F.txt'
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    
   
    cacheFile=os.path.join(user_dataDir2,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir2)

        unzip(os.path.join(user_dataDir2, "fixed_list.txt"),user_dataDir2)

    else:

        all_img=cache.get(renew_data,1,user_dataDir2,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string)
    
       
        
    match = dbcur.fetchall()
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub3.append((name,f_link,5,'[[AV]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1



def get_dub_movies5():
    global all_dub5
    '''
    l_list='https://github.com/drmpon/drmpon/blob/master/333.txt?raw=true'
    logging.warning('Start 7')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir4,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir4)

        unzip(os.path.join(user_dataDir4, "fixed_list.txt"),user_dataDir4)

    else:

        all_img=cache.get(renew_data,1,user_dataDir4,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string_dragon)
    match = dbcur.fetchall()
    logging.warning('Dragon Found:'+str(len(match)))
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
       
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
            
        all_dub5.append((name,f_link,5,'[[Dr]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1
    '''
def get_dub_movies6():
    global all_dub6
    all_dub6=[]
    l_list='https://github.com/moris0371/CHICCO/raw/master/moris.txt'
    logging.warning('Start 6')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir5,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir5)

        unzip(os.path.join(user_dataDir5, "fixed_list.txt"),user_dataDir5)

    else:

        all_img=cache.get(renew_data,1,user_dataDir5,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string_dragon)
    match = dbcur.fetchall()
    logging.warning('Chicko Found:'+str(len(match)))
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
       
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
            
        all_dub6.append((name,f_link,5,'[[CK]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1

def get_dub_movies7():
    global all_dub4
    all_dub6=[]
    l_list='https://github.com/sparkonet/joker/raw/master/killers.txt'
    logging.warning('Start 6')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir6,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir6)

        unzip(os.path.join(user_dataDir6, "fixed_list.txt"),user_dataDir6)

    else:

        all_img=cache.get(renew_data,1,user_dataDir6,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string_dragon)
    logging.warning(master_string_dragon)
    match = dbcur.fetchall()
    logging.warning('Kille Found:'+str(len(match)))
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
       
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

        name=remove_color(name)
        regex='\{(.+?)\}'
        m=re.compile(regex).findall(name)
        if len(m)>0:
            name=name.replace('{'+m[0]+'}','').strip()
        all_dub4.append((name,f_link,5,'[[KL]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1
def get_dub_movies8():
    global all_dub8
    all_dub6=[]
    l_list='https://github.com/hpotter1234/matrix/raw/master/subbed.txt'
    logging.warning('Start 8')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir7,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir7)

        unzip(os.path.join(user_dataDir7, "fixed_list.txt"),user_dataDir7)

    else:

        all_img=cache.get(renew_data,1,user_dataDir7,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute(master_string_dragon)
    match = dbcur.fetchall()
    logging.warning('Chicko HP:'+str(len(match)))
    counter=0
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
       
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
            
        all_dub8.append((name,f_link,5,'[[HP]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
        if counter>amount_per_master:
            break
        counter+=1
def get_background_data(now=False,dp=''):
    global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6
    import xbmcgui
    if now==False:
    
        while 1:
            if  xbmc.Player().isPlaying() :
                if  xbmc.Player().getTime()>10:
                    break
            xbmc.sleep(100)
    else:
        if Addon.getSetting("master_dp")=='true':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','טוען', '','')
            dp.update(0, 'אנא המתן','טוען', '' )
            
    addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'master_movies')
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    
    logging.warning('Waiting for play')
    
    
    logging.warning('Done Waiting')
    thread=[]
    
    thread.append(Thread(get_dub_movies))
    thread[len(thread)-1].setName('Or')
    
    thread.append(Thread(get_dub_movies2))
    thread[len(thread)-1].setName('GH')
    thread.append(Thread(get_dub_movies3))
    thread[len(thread)-1].setName('AV')
    #thread.append(Thread(get_dub_movies4))
    thread.append(Thread(get_dub_movies5))
    thread[len(thread)-1].setName('D')
    thread.append(Thread(get_dub_movies6))
    thread[len(thread)-1].setName('CH')
    thread.append(Thread(get_dub_movies7))
    thread[len(thread)-1].setName('KL')
    thread.append(Thread(get_dub_movies8))
    thread[len(thread)-1].setName('HP')
    
    for td in thread:
          td.start()
    
    while 1:

        
        
        
        for threads in thread:
            all_alive=[]
            still_alive=0
            xx=0
            for yy in range(0,len(thread)):
                    if thread[yy].is_alive():
                      all_alive.append(thread[yy].name)
                        
                      still_alive=1
                    else:
                        xx+=1
            xbmc.sleep(300)
        if Addon.getSetting("master_dp")=='true':
            dp.update(int(((xx* 100.0)/(len(thread))) ), 'אנא המתן','אוסף', ','.join(all_alive) )
        if still_alive==0:
          break
    if Addon.getSetting("master_dp")=='true':
        dp.close()
    logging.warning('all_dub:'+str(len(all_dub)))
    logging.warning('all_dub2:'+str(len(all_dub2)))
    logging.warning('all_dub3:'+str(len(all_dub3)))
    logging.warning('all_dub4:'+str(len(all_dub4)))
    logging.warning('all_dub5:'+str(len(all_dub5)))
    logging.warning('all_dub6:'+str(len(all_dub6)))

    logging.warning('all_dub8:'+str(len(all_dub8)))
    all_data_tog=all_dub+all_dub2+all_dub3+all_dub4+all_dub5+all_dub6+all_dub8
    '''
    for name1,link,con1,origin,icon,image,plot,data in all_data_tog:
    
        dbcur.execute("SELECT * FROM master_movies where name='%s'"%name1)
        match = dbcur.fetchall()
        if match==None:
            dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?,?,?)" % 'newones', (name1.decode('utf8'),link.decode('utf8'),con1,origin.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),data.decode('utf8')))
    '''
    dbcur.execute("DELETE FROM master_movies")
    for name1,link,con1,origin,icon,image,plot,data in all_data_tog:
       dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?,?,?)" % 'master_movies', (name1.decode('utf8'),link.decode('utf8'),con1,origin.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),data.decode('utf8')))
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    
    logging.warning('Done Update')
    return 'OK'
def html_decode(s):
   
    """
    Returns the ASCII decoded version of the given HTML string. This does
    NOT remove normal HTML tags like <p>.
    """
    htmlCodes = (
            ("'", '&#39;'),
            ("'", '&#039;'),
            ('"', '&quot;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('-','&#8211;'),
            ('...','&#8230;'),
            ('&', '&amp;')
        )
    for code in htmlCodes:
        s = s.replace(code[1], code[0])
    return s
def get_background_data_ms():
        thread=[]
        thread.append(Thread(get_background_data))
        thread[0].start()
        return 'OK'
def remove_color(name):
  
    regex='\[COLOR(.+?)\]'
    m=re.compile(regex).findall(name)
    if len(m)>0:
        for items in m:
            name=name.replace('[COLOR%s]'%items,'')
    regex='◄(.+?)►'
    m=re.compile(regex).findall(name)
    if len(m)>0:
        for items in m:
            name=name.replace('◄%s►'%items,'')
    regex='►(.+?)◄'
    m=re.compile(regex).findall(name)
    if len(m)>0:
        for items in m:
            name=name.replace('►%s◄'%items,'')
    
    return name.replace('[/COLOR]','').replace('[/B]','').replace('[B]','').replace('[I]','').replace('[/I]','').replace(' FHD ','').replace(' HD ','')
    
def get_master_movies(page,search_entered=''):
        
        global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6
        import xbmcgui
        dp=''
        all_items_sor=[]
        if Addon.getSetting("master_dp")=='true':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','טוען', '','')
            dp.update(0, 'אנא המתן','טוען', '' )
  
        
    
        x=cache.get(get_background_data,24,True,'', table='posters')
        
        addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
        tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
        tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
        dbcon = database.connect(tmdb_cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'master_movies')
        dbcon.commit()
        dbcur.execute("SELECT * FROM master_movies")
        match = dbcur.fetchall()
        max_result=len(match)
        per_page=Addon.getSetting("master_no1")
        if page!='0':
            n_page=str(int(page)*int(per_page))
        else:
            n_page='0'
        dbcur.execute("SELECT * FROM master_movies ")

        match = dbcur.fetchall()

        all_links={}
        all_names=[]
        
        xx=0
        for name1,link,con1,origin,icon,image,plot,data in match:
          
          if 'ActivateWindow' in link:
            continue
          if Addon.getSetting("master_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף', name1 )
              xx+=1
          name1=name1.decode('utf8').strip().replace('*מדובב*','').replace('*','').replace('-',' ').strip()
          #name1=remove_color(name1)
          
          fault_data=0
          
          dd=''
          
          data2={}
          
          try:
            name1=json.loads(data)['title'].replace('-',' ')
            dd=fix_date(json.loads(data)['dateadded'])
            data2=json.loads(data)
            
          except Exception as e:
            logging.warning(e)
            try:
             data=data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace(': """",',': "" "",').replace(': """"}',': "" ""}').replace(': "",',': " ",').replace(': ""}',': " "}').replace('""','"').replace('\n','').replace('\r','')
             name1=json.load(data)['title'].replace('-',' ')
             dd=fix_date(json.loads(data)['dateadded'])
             data2=json.loads(data)
             
            except Exception as e:
             
             fault_data=1
             pass
          
          if name1 not in all_names:
             date_added=''
            
             
             try:
                data2['plot']=origin.replace('[','').replace(']','')+'\n[COLOR lightblue]'+dd+'[/COLOR]\n'+data2['plot']+'-HebDub-'
                data2['dateadded']=fix_date(data2['dateadded']).strip()
                date_added=data2['dateadded']
                #data2['title']=name1
                data=json.dumps(data2)
             except Exception as e:
                logging.warning('Error in sort:'+str(e))
                logging.warning(name1)
                logging.warning(data2)
               
                pass
             all_names.append(name1)
             all_links[name1]={}
             all_links[name1]['icon']=icon
             all_links[name1]['image']=image
             all_links[name1]['plot']=dd+'\n'+plot
             all_links[name1]['data']=data
             all_links[name1]['link']=origin+link
             all_links[name1]['origin']=origin.replace('[','').replace(']','')
             all_links[name1]['dateadded']=date_added
          else:
               date_added=''
               if 1:#if link not in all_links[name1]['link']:
                 
                 all_links[name1]['origin']=all_links[name1]['origin']+','+origin.replace('[','').replace(']','')
                 try:
                    data2['plot']=all_links[name1]['origin']+'\n[COLOR lightblue]'+dd+'[/COLOR]\n'+data2['plot']+'-HebDub-'
                    data2['dateadded']=fix_date(data2['dateadded']).strip()
                    date_added=data2['dateadded']
                    data=json.dumps(data2)
                    all_links[name1]['data']=data
                 except:
                    pass
                 if '$$$' in link:
                      links=link.split('$$$')
                      for link in links:
                        all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link
                 else:
                   all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link
                 all_links[name1]['dateadded']=date_added
        xx=0
        for items in all_links:
            
            if Addon.getSetting("master_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(all_links))) ), 'אנא המתן','שלב 2', items )
              xx+=1
            
            link=all_links[items]['link']
            icon=all_links[items]['icon']
            image=all_links[items]['image']
            plot=all_links[items]['plot']+'-HebDub-'
            data=all_links[items]['data']
            date_added=all_links[items]['dateadded']
            if search_entered=='':
            
              if fault_data==1:
                logging.warning('Fault')
                data={}
                data['title']=items
                data['name']=items
                data['icon']=icon
                data['fanart']=image
                data['plot']=plot
                data=json.dumps(data)
                
              try:
                aa=json.loads(data)['title'].replace('-',' ')
                
              except:
                data={}
                data['title']=items
                data['name']=items
                data['icon']=icon
                data['fanart']=image
                data['plot']=plot
                data=json.dumps(data)
              try:
                  data2=json.loads(data)
                  show_original_year=data2['year']
                  original_title=data2['originaltitle']
                  id=data2['imdb']
                  
              except Exception as e:
                logging.warning('Data2:'+str(e))
                show_original_year=''
                original_title=''
                id=''
              
             
              
              eng_name=original_title
              heb_name=items
              all_items_sor.append((items,link,icon,image,plot+'-HebDub-',show_original_year,original_title,id,eng_name,heb_name,show_original_year,data,date_added))
              #addLink(items,link,5,False,icon,image,plot+'-HebDub-',data=show_original_year,original_title=original_title,id=id,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,video_info=data,dont_earse=True)
                
              #addLink(items,link,5,False,icon,image,plot+'-HebDub-',video_info=data,dont_earse=True)
            else:
              if search_entered in items  :
           
                all_items_sor.append((items,link,icon,image,plot+'-HebDub-','',items,'',items,items,'',data,date_added))
                
                #addLink(items,link,5,False,icon,image,plot+'-HebDub-',video_info=data,dont_earse=True)
       
        all_items_sor=sorted(all_items_sor, key=lambda x: x[12], reverse=True)
        xx=0
        logging.warning('From:'+str(n_page))
        logging.warning('to:'+str(n_page+per_page))
        for items,link,icon,image,plot,show_original_year,original_title,id,eng_name,heb_name,show_original_year,data,date_added in all_items_sor:
            xx+=1
            
            if (xx>int(n_page)) and (xx<(int(n_page)+int(per_page))):
              
                if Addon.getSetting("master_dp")=='true':
                    dp.update(int(((xx* 100.0)/(len(all_items_sor))) ), 'אנא המתן','מוסיף', items )
                
                if Addon.getSetting("play_master")=='1':
                    #addDir3(items,link,4,icon,image,plot,data=show_original_year,original_title=original_title,id=id,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,video_info=json.loads(data))
                    addLink(items,link,4,True,icon,image,plot,data=show_original_year,original_title=original_title,id=id,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,video_info=data,dont_earse=True,shortcut=True)
                else: 
                    addLink(items,link,5,False,icon,image,plot,data=show_original_year,original_title=original_title,id=id,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,video_info=data,dont_earse=True)
        if Addon.getSetting("master_dp")=='true':
              dp.update(100, 'אנא המתן','סיימתי', ' ' )
              dp.close()
        logging.warning((int(page)*int(per_page)))
        logging.warning(max_result)
        if page!=str(max_result/int(per_page)):
            addDir3('[COLOR aqua][I] עמוד %s מתוך %s[/COLOR][/I]'%(page,str(max_result/int(per_page))),str(int(page)+1),147,' ',' ','[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED,'descending')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
        dbcur.close()
        dbcon.close()
        
        #all_img=cache.get(get_background_data_ms,24, table='posters')
        #get_dub_movies()









        